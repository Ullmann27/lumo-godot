#!/usr/bin/env python3
"""Preserve ce909 and its actual failed observation; prepare one external delta.

This is file/provenance preparation and arithmetic over original JSON, not a
Godot import, test, simulation of a renderer, or product execution.
"""
from __future__ import annotations

import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
CHECKOUT = WORKSPACE / "native-ce909c4-import-validation-20261114/checkout"
EVIDENCE = WORKSPACE / "host-next-authorities-bca533-native-evidence-20261114"
ORIGINALS = EVIDENCE / "artifacts/14125310534/inspection/originals"
NATIVE_SHA = "ce909c4d3bab3a5514b653bf945a0ef46adfa539"
NATIVE_TREE = "e2a374b2154f7ecb080f693c4bc90def53a20a00"
SOURCE = "scripts/learning/learning_world.gd"
SOURCE_BLOB = "8d2c67ac7e630610093f02a5093d6f06e204d88a"
SOURCE_SHA256 = "c9238933216622c255b73ceb52d251491cd154c04e64db6d55b23c4e5ac1ad2f"
LAYOUT = "english-native/english-ruler-640x360-start.layout.json"
LAYOUT_SHA256 = "305655b062f30a9c1ceb53c882d6310b3fd2bde8531f0efc0fc047e996f6164c"


def identity(data: bytes) -> dict:
    return {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    }


def write(path: str, data: bytes) -> dict:
    destination = ROOT / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("xb") as stream:
        stream.write(data)
    if destination.read_bytes() != data:
        raise ValueError("Original readback mismatch: " + path)
    return {"path": path, **identity(data)}


def write_json(path: str, value: object) -> dict:
    return write(path, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode())


def git(*args: str) -> tuple[bytes, bytes]:
    result = subprocess.run(
        ["git", "-C", str(CHECKOUT), *args], capture_output=True,
        env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"}, check=False,
    )
    if result.returncode:
        raise ValueError("Read-only Git command failed: " + repr(args))
    return result.stdout, result.stderr


def blocks(source: str) -> dict[str, str]:
    matches = list(re.finditer(r"^func ([A-Za-z0-9_]+)\(", source, re.MULTILINE))
    return {
        match.group(1): source[match.start():matches[index + 1].start() if index + 1 < len(matches) else len(source)]
        for index, match in enumerate(matches)
    }


def rect(points: list[list[float]]) -> list[float]:
    xs = [point[0] for point in points]
    ys = [point[1] for point in points]
    return [min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)]


def project(point: list[float], observation: dict) -> list[float]:
    camera = observation["camera"]
    basis = camera["view_basis_columns"]
    position = camera["view_origin"]
    view = [sum(basis[column][row] * point[column] for column in range(3)) + position[row] for row in range(3)] + [1.0]
    projection = camera["projection_columns"]
    clip = [sum(projection[column][row] * view[column] for column in range(4)) for row in range(4)]
    width, height = observation["viewport_px"]
    return [(clip[0] / clip[3] + 1.0) * width * 0.5, (1.0 - clip[1] / clip[3]) * height * 0.5]


def main() -> None:
    head, head_stderr = git("rev-parse", "HEAD")
    tree, tree_stderr = git("rev-parse", "HEAD^{tree}")
    if head.decode().strip() != NATIVE_SHA or tree.decode().strip() != NATIVE_TREE:
        raise ValueError("Checkout differs from the actual failed CI source")
    index_path_raw, index_stderr = git("rev-parse", "--git-path", "index")
    index_path = Path(index_path_raw.decode().strip())
    if not index_path.is_absolute():
        index_path = CHECKOUT / index_path
    index_before = index_path.read_bytes()
    status_before, status_stderr = git("status", "--porcelain=v1", "--untracked-files=no")
    if status_before:
        raise ValueError("Tracked source is not clean")
    original, source_stderr = git("show", "HEAD:" + SOURCE)
    if (CHECKOUT / SOURCE).read_bytes() != original:
        raise ValueError("Working source differs from committed source")
    original_identity = identity(original)
    if original_identity["git_blob"] != SOURCE_BLOB or original_identity["sha256"] != SOURCE_SHA256:
        raise ValueError("Unexpected source identity")
    inventory_bytes = (ORIGINALS / "source/native/source-inventory-before.json").read_bytes()
    inventory = json.loads(inventory_bytes)
    tracked = {entry["path"]: entry for entry in inventory["tracked"]}
    if inventory["head"] != NATIVE_SHA or inventory["tree"] != NATIVE_TREE:
        raise ValueError("Original CI inventory has a foreign source identity")
    for field in ("bytes", "sha256", "git_blob"):
        if tracked[SOURCE][field] != original_identity[field]:
            raise ValueError("Current source does not match the original CI inventory")

    before = original.decode()
    reset_before = "\tfor index in range(english_models.size()):\n\t\tenglish_models[index].position = (\n"
    reset_after = "\tfor index in range(english_models.size()):\n\t\tenglish_models[index].scale = Vector3.ONE\n\t\tenglish_models[index].position = (\n"
    if before.count(reset_before) != 1:
        raise ValueError("Model reset hunk is ambiguous")
    after = before.replace(reset_before, reset_after)
    call_before = "\tcamera.h_offset = -shift.x / pixels_per_unit\n\tcamera.v_offset = shift.y / pixels_per_unit\n\tif fox.is_usable():\n"
    call_after = "\tcamera.h_offset = -shift.x / pixels_per_unit\n\tcamera.v_offset = shift.y / pixels_per_unit\n\tif not portrait:\n\t\t_enlarge_english_landscape_objects()\n\tif fox.is_usable():\n"
    if after.count(call_before) != 1:
        raise ValueError("Final layout call hunk is ambiguous")
    after = after.replace(call_before, call_after)
    helper = '''func _enlarge_english_landscape_objects() -> void:
	# The shared camera fit can leave low objects below 48dp in short windows.
	# Enlarge the actual meshes and collision bodies together, then lay out
	# their measured bounds beside Lumo without changing the camera or HUD.
	var density: float = MobileRuntime.get_ui_density()
	var minimum_edge := INF
	var rectangles: Array[Rect2] = []
	for model: Node3D in english_models:
		var bounds := _english_projected_bounds(model)
		if not bounds.has_area():
			return
		rectangles.append(bounds)
		minimum_edge = minf(minimum_edge, minf(bounds.size.x, bounds.size.y))
	if minimum_edge >= 48.0 * density:
		return
	var enlargement := 52.0 * density / minimum_edge
	var gap := 8.0 * density
	var teacher_bounds := _english_projected_bounds(fox)
	var left := maxf(english_stage_rect.position.x, teacher_bounds.end.x + gap)
	var row_width := gap * (english_models.size() - 1)
	var row_height := 0.0
	for bounds: Rect2 in rectangles:
		row_width += bounds.size.x * enlargement
		row_height = maxf(row_height, bounds.size.y * enlargement)
	# Preserve full containment and the original teacher. If a future window
	# cannot fit this row, the unchanged measured 48dp regression still fails.
	if row_width > english_stage_rect.end.x - left or row_height > english_stage_rect.size.y:
		return
	var pixels_per_x := camera.unproject_position(Vector3.RIGHT).x - camera.unproject_position(Vector3.ZERO).x
	var pixels_per_depth := camera.unproject_position(Vector3.BACK).y - camera.unproject_position(Vector3.ZERO).y
	if pixels_per_x <= 0.001 or pixels_per_depth <= 0.001:
		return
	var cursor := left + (english_stage_rect.end.x - left - row_width) * 0.5
	for model: Node3D in english_models:
		model.scale = Vector3.ONE * enlargement
		var number := model.get_node("ChoiceNumber") as MeshInstance3D
		number.global_basis = camera.global_basis.scaled(Vector3.ONE * enlargement)
		var bounds := _english_projected_bounds(model)
		model.position.x += (cursor - bounds.position.x) / pixels_per_x
		model.position.z += (english_stage_rect.get_center().y - bounds.get_center().y) / pixels_per_depth
		cursor += bounds.size.x + gap


'''
    anchor = "func english_pick_rect(index: int) -> Rect2:\n"
    if after.count(anchor) != 1:
        raise ValueError("Helper insertion point is ambiguous")
    after = after.replace(anchor, helper + anchor)
    final = after.encode()
    before_blocks, after_blocks = blocks(before), blocks(after)
    changed = [name for name in before_blocks if before_blocks[name] != after_blocks.get(name)]
    added = sorted(set(after_blocks) - set(before_blocks))
    if changed != ["_layout_english"] or added != ["_enlarge_english_landscape_objects"]:
        raise ValueError("Unexpected function-level scope")
    protected = {name: identity(body.encode()) for name, body in before_blocks.items() if name not in changed}
    rows = [write("before/" + SOURCE, original), write("final-source/" + SOURCE, final)]
    rows.append(write("integration.patch", "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="a/" + SOURCE, tofile="b/" + SOURCE)).encode()))
    rows.append(write_json("preserved-functions.json", {"unchanged_count": len(protected), "unchanged": protected, "changed": changed, "added": added}))

    references = [
        "scripts/learning/english_object_gallery.gd",
        "scripts/learning/english_vocabulary.gd",
        "scripts/learning/learning_activity.gd",
        "scripts/tests/learning_english_regression.gd",
    ]
    source_records = {SOURCE: original_identity}
    for path in references:
        data, stderr = git("show", "HEAD:" + path)
        if (CHECKOUT / path).read_bytes() != data or identity(data)["sha256"] != tracked[path]["sha256"]:
            raise ValueError("Reference source mismatch: " + path)
        rows.append(write("reference-source/" + path, data))
        source_records[path] = identity(data)
    layout_bytes = (ORIGINALS / LAYOUT).read_bytes()
    if identity(layout_bytes)["sha256"] != LAYOUT_SHA256:
        raise ValueError("Failure projection observation changed")
    observation = json.loads(layout_bytes)
    rows.append(write("originals/" + LAYOUT, layout_bytes))
    rows.append(write("originals/english-activity.json", (ORIGINALS / "english-activity.json").read_bytes()))
    rows.append(write("originals/english-render.log", (ORIGINALS / "english-render.log").read_bytes()))
    rows.append(write("originals/english-render-runner.log", (ORIGINALS / "english-render-runner.log").read_bytes()))
    geometry = []
    maximum_projection_error = 0.0
    for item in observation["objects"]:
        pixels = [point for mesh in item["meshes"] for point in mesh["projected_corners_px"]]
        bounds = rect(pixels)
        for mesh in item["meshes"]:
            for world, recorded in zip(mesh["world_corners"], mesh["projected_corners_px"], strict=True):
                calculated = project(world, observation)
                maximum_projection_error = max(maximum_projection_error, *(abs(calculated[axis] - recorded[axis]) for axis in (0, 1)))
        geometry.append({"word": item["word"], "index": item["index"], "actual_mesh_count": len(item["meshes"]), "original_bounds_px": bounds, "original_minimum_dp": min(bounds[2:]) / observation["density"], "original_pick_rect_px": item["pick_rect_px"]})
    minimum = min(row["original_minimum_dp"] for row in geometry)
    factor = 52.0 / minimum
    for row in geometry:
        row["predicted_uniform_scale_size_px"] = [value * factor for value in row["original_bounds_px"][2:]]
        row["predicted_minimum_dp"] = row["original_minimum_dp"] * factor
    stage = observation["stage_rect_px"]
    row_width = sum(row["predicted_uniform_scale_size_px"][0] for row in geometry) + 16.0 * observation["density"]
    analysis = {
        "scope": "Arithmetic from actual original camera/world-corner observations; no new renderer or test result",
        "source": {"head": NATIVE_SHA, "tree": NATIVE_TREE, "path": SOURCE, **original_identity},
        "original": {"path": str(ORIGINALS / LAYOUT), **identity(layout_bytes)},
        "actual_density": observation["density"], "actual_viewport_px": observation["viewport_px"],
        "actual_stage_rect_px": stage,
        "actual_orthographic_size_from_projection": 2.0 / observation["camera"]["projection_columns"][1][1],
        "actual_projection_world_corner_recalculation_max_error_px": maximum_projection_error,
        "objects": geometry,
        "first_failing_object_in_probe_order": geometry[0]["word"],
        "proposed_uniform_enlargement_for_this_recorded_layout": factor,
        "predicted_row_width_including_two_8dp_gaps_px": row_width,
        "predicted_row_height_px": max(row["predicted_uniform_scale_size_px"][1] for row in geometry),
        "maximum_allowed_teacher_right_x_for_this_predicted_row_px": stage[0] + stage[2] - row_width - 8.0 * observation["density"],
        "teacher_bounds_limitation": "The failed layout does not include Lumo mesh corners. The production repair reads the actual current teacher bounds and refuses an enlargement that cannot fit; only the future real renderer can confirm the resulting entire frame.",
        "missing_originals": ["english-ruler-640x360-start.png", "english-ruler-640x360-start.json", "learning-english-report.json"],
        "unchanged_gate": "learning_english_regression.gd still requires each actual visible object >=48dp on both axes, complete stage containment, separation, readable original Lumo, real actions and lifecycle/voice/return contracts",
        "new_renderer_success": False,
    }
    if maximum_projection_error > 0.001:
        raise ValueError("Original projection recalculation disagrees with recorded corners")
    rows.append(write_json("projection-analysis.json", analysis))
    if index_path.read_bytes() != index_before:
        raise ValueError("Local checkout index changed during read-only preparation")
    status_after, after_stderr = git("status", "--porcelain=v1", "--untracked-files=no")
    if status_after != status_before or (CHECKOUT / SOURCE).read_bytes() != original:
        raise ValueError("Local tracked source changed during preparation")
    after_head, _ = git("rev-parse", "HEAD")
    after_tree, _ = git("rev-parse", "HEAD^{tree}")
    if after_head != head or after_tree != tree:
        raise ValueError("Local source identity changed during preparation")
    rows.append(write_json("source-read-binding.json", {
        "head": NATIVE_SHA, "tree": NATIVE_TREE, "checkout": str(CHECKOUT),
        "actual_original_ci_inventory": {"path": str(ORIGINALS / "source/native/source-inventory-before.json"), **identity(inventory_bytes)},
        "sources": source_records,
        "index_before_after_sha256": hashlib.sha256(index_before).hexdigest(),
        "tracked_status_before_after": status_before.decode(),
        "stderr_originals": {"head": head_stderr.decode(), "tree": tree_stderr.decode(), "index_path": index_stderr.decode(), "status_before": status_stderr.decode(), "source_git_show": source_stderr.decode(), "status_after": after_stderr.decode()},
        "warning_scope": "Read-only Git reported a missing old /tmp alternate object directory. All selected source objects were nevertheless returned with rc0 and matched the actual CI inventory. No Git configuration, source, index or ref was changed.",
    }))
    freeze = {
        "schema": 1, "status": "FROZEN_SOURCE_ONLY_NOT_EXECUTED",
        "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "base_head": NATIVE_SHA, "base_tree": NATIVE_TREE,
        "source": {"path": SOURCE, "mode": "100644", "before": original_identity, "after": identity(final)},
        "changed_existing_functions": changed, "new_functions": added,
        "protected_function_count": len(protected),
        "unchanged_reference_sources": {path: source_records[path] for path in references},
        "no_test_or_engine_execution": True, "no_git_mutations": True,
        "required_next_validation": "After Root's source checkpoint: the unchanged actual English renderer with current Host-generated fixtures, all 14 profiles, 17 captures, hint/lifecycle/voice/return checks and unchanged >=48dp threshold. No prior Producer or failed CI result is transferable to the proposed source.",
    }
    rows.append(write_json("source-freeze.json", freeze))
    rows.append({"path": "prepare_source_pack.py", **identity(Path(__file__).read_bytes())})
    write_json("preparation-results.json", {"original_readback_equal": True, "files": rows, "source_identity": freeze["source"], "projection_recalculation_max_error_px": maximum_projection_error})
    print(json.dumps({"pack": str(ROOT), "source": freeze["source"], "changed": changed, "preserved_functions": len(protected), "projection_max_error_px": maximum_projection_error, "enlargement_prediction": factor, "new_engine_or_tests_run": False}, indent=2))


if __name__ == "__main__":
    main()
