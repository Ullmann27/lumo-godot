#!/usr/bin/env python3
"""Create immutable local handoffs and byte-checked archives, without tests."""
from __future__ import annotations
import datetime
import hashlib
import io
import json
from pathlib import Path
import tarfile

P = Path(__file__).resolve().parent
E = P.parent / 'host-next-authorities-bca533-native-evidence-20261114'


def ident(b):
    return {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()}


def save(root, name, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(data)
    if path.read_bytes() != data:
        raise ValueError('Written original differs: ' + str(path))
    return {'path': name, **ident(data)}


def archive(root, archive_name, paths):
    records = []
    with (root / archive_name).open('xb') as raw:
        with tarfile.open(fileobj=raw, mode='w:gz') as tar:
            for path in sorted(paths):
                b = path.read_bytes()
                name = str(path.relative_to(root))
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(b), 0o644, 0
                tar.addfile(info, io.BytesIO(b))
                records.append({'path': name, **ident(b)})
    with tarfile.open(root / archive_name, 'r:gz') as tar:
        if tar.getnames() != [r['path'] for r in records]:
            raise ValueError('Archive member order/count mismatch')
        for record in records:
            b = tar.extractfile(record['path']).read()
            if ident(b) != {k: record[k] for k in ('bytes', 'sha256', 'git_blob')} or b != (root / record['path']).read_bytes():
                raise ValueError('Archive original roundtrip mismatch: ' + record['path'])
    return {'path': archive_name, **ident((root / archive_name).read_bytes()), 'members': records, 'every_member_original_byte_equal': True}


def main():
    binding = json.loads((E / 'expected-source-binding.json').read_bytes())
    run = json.loads((E / 'final/run.json').read_bytes())
    jobs = json.loads((E / 'snapshots/20261114T175604Z/jobs.json').read_bytes())
    artifacts = json.loads((E / 'final/artifacts.json').read_bytes())
    if (run['id'], run['head_sha'], run['run_attempt'], run['status'], run['conclusion']) != (43623178880, binding['host'], 1, 'completed', 'failure'):
        raise ValueError('Final run identity/status mismatch')
    final_jobs = [{k: job.get(k) for k in ('id', 'name', 'head_sha', 'run_id', 'run_attempt', 'status', 'conclusion', 'started_at', 'completed_at', 'html_url')} for job in jobs['jobs']]
    if len(final_jobs) != 5 or any(job['status'] != 'completed' for job in final_jobs):
        raise ValueError('Final jobs do not contain five completed jobs')
    remote = {
        'final/run.json': 'f966ba8191933d54d220200b1f070354e0003d6f',
        'final/artifacts.json': 'f6f8691247cb0a1f4ab2f5596168eaa7a73d5355',
        'snapshots/20261114T175604Z/jobs.json': '29874e351b18f263346fde8d0a81f834d01446a6',
        'jobs/memory-132533159301.log': 'd3c055440ec667bc45d30698c9a08cc7c938a8d8',
        'jobs/quiz-132533159317.log': '4d23ddf686f317074e3b1f7ad6b2f70523f75095',
        'jobs/english-132533159373.log': 'abdf13117057d1fe199bf9a14de0d2e376cfff26',
    }
    remote_records = []
    for name, blob in remote.items():
        record = ident((E / name).read_bytes())
        if record['git_blob'] != blob:
            raise ValueError('Immutable remote original identity differs: ' + name)
        remote_records.append({'path': name, 'repository': 'Ullmann27/lumo-lernen', 'remote_blob_created_and_full_readback_equal': True, **record})
    save(E, 'immutable-original-bindings.json', remote_records)
    local_archives = []
    for aid in (14125310534, 14125430494):
        verification_path = E / f'artifacts/{aid}/inspection/verification.json'
        verification = json.loads(verification_path.read_bytes())
        record = next(x for x in artifacts['artifacts'] if x['id'] == aid)
        z = E / f'artifacts/{aid}/original.zip'
        zi = ident(z.read_bytes())
        if zi['bytes'] != record['size_in_bytes'] or 'sha256:' + zi['sha256'] != record['digest']:
            raise ValueError('Original retained archive changed')
        local_archives.append({'id': aid, 'path': str(z), **zi, 'original_catalog': str(verification_path),
            'catalog_identity': ident(verification_path.read_bytes()),
            'members': len(verification['members']), 'fully_decoded_pngs': len(verification['pngs']),
            'original_export_count_by_this_agent': 1,
            'full_crc_sha_and_materialized_readback': verification['all_members_crc_sha_verified'] and verification['all_regular_originals_materialized_and_readback_equal']})
    save(E, 'terminal-handoff.json', {
        'schema': 1, 'status': 'FROZEN_ORIGINAL_FAILURE_EVIDENCE',
        'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'binding': binding, 'run_status': run['status'], 'run_conclusion': run['conclusion'],
        'jobs': final_jobs, 'polling_ended_at_final_snapshot': True,
        'original_archives_owned_here': local_archives,
        'memory_archive_owner': '/root/flutter_integration; no Memory export by this agent',
        'android_and_flutter_log_archive_owner': '/root/flutter_integration',
        'actual_native_outcomes': {
            'quiz': 'Actual 381 checks/6 captures and QuizNativePair PASS; independent PNG decode successful; job subsequently fails Native binary-index hash invariant.',
            'english': 'Actual Dart 10 cases/2955 checks PASS; rendered probe rejects the real object projection at 640x360; independent final English acceptance never completed; binary-index invariant also fails.',
            'memory': 'Actual view 7020 checks/8 captures and pair 244 checks/57 inputs PASS; independent decoder rejects marker agreement; binary-index invariant also fails. Decoder analysis owned by Flutter.',
        },
        'source_inventory_original_locations': ['artifacts/14125310534/inspection/originals/source/', 'artifacts/14125430494/inspection/originals/source/'],
        'binary_index_retention': 'Full archive catalogs contain original index stage dumps and before/after inventories, but no raw before/after .git/index byte copies. A stage dump must not be described as such a copy.',
        'english_missing_originals': ['english-ruler-640x360-start.png', 'english-ruler-640x360-start.json', 'learning-english-report.json'],
        'new_product_engine_or_test_runs': 0,
        'new_device_fps_or_qualification_success': False,
    })
    e_files = [f for f in E.rglob('*') if f.is_file()]
    excluded = [f for f in e_files if f.suffix in ('.zip', '.png')]
    included = [f for f in e_files if f not in excluded]
    save(E, 'technical-inclusions.json', [{'path': str(f.relative_to(E)), **ident(f.read_bytes())} for f in sorted(included)])
    save(E, 'retained-separate-originals.json', [{'path': str(f.relative_to(E)), 'retained_locally_unchanged': True, 'reason': 'Full original archive or raster retained separately; never recoded or replaced', **ident(f.read_bytes())} for f in sorted(excluded)])
    included += [E / 'technical-inclusions.json', E / 'retained-separate-originals.json']
    technical = archive(E, 'compact-technical-originals.tar.gz', included)
    save(E, 'technical-roundtrip.json', technical)
    save(E, 'manifest.json', {'scope': 'Terminal original API/log/source/transport evidence, not a new qualification', 'binding': binding, 'technical_archive': {k:v for k,v in technical.items() if k != 'members'}, 'technical_member_count': len(technical['members']), 'separate_originals': [{'path': str(f.relative_to(E)), **ident(f.read_bytes())} for f in sorted(excluded)]})

    png_names = ['english-ball-960x540-start.png', 'english-book-412x915-start.png']
    seen = []
    for name in png_names:
        file = E / 'artifacts/14125310534/inspection/originals/english-native' / name
        seen.append({'original_path': str(file), **ident(file.read_bytes()), 'actually_opened_by_agent': True,
            'observation': 'Original Lumo and all three numbered object illustrations are visible, with the English title and actions. This is the earlier ball landscape view.' if 'ball' in name else 'Original Lumo and the ruler, pencil-case and book illustrations are visible in a vertical stack with numbered choices and return/action buttons. This is the earlier book portrait view.'})
    save(P, 'original-image-observations.json', {'scope': 'Two direct original-image sightings only; no sighting of the missing failed ruler frame and no visual acceptance of the proposed product source', 'seen': seen})
    save(P, 'handoff.json', {
        'schema': 1, 'status': 'FROZEN_SOURCE_PROPOSAL_AWAITING_ROOT_CHECKPOINT_AND_REAL_RENDERER',
        'source_freeze': {'path': 'source-freeze.json', **ident((P / 'source-freeze.json').read_bytes())},
        'patch': {'path': 'integration.patch', **ident((P / 'integration.patch').read_bytes())},
        'source': json.loads((P / 'source-freeze.json').read_bytes())['source'],
        'actual_failed_run': binding, 'actual_job': 132533159373, 'actual_artifact': 14125310534,
        'original_pack': str(E), 'terminal_handoff': str(E / 'terminal-handoff.json'),
        'original_geometry_analysis': 'projection-analysis.json',
        'protected': 'All 66 other functions, top-level declarations, gallery, original Lumo, Wisp, speech/PCM/consent, lifecycle, returns and unmodified strict regression. Portrait uses reset unit scale; repeated layouts do not multiply prior enlargement.',
        'changed_file_count': 1, 'new_engine_or_test_execution': False,
        'open': ['Source checkpoint and independent review', 'Actual new renderer with the current Host-generated task fixture', 'All original 14 profiles/17 captures and hint/orientation/lifecycle checks', 'Root binary-index guard correction and Flutter Memory marker correction are separate scopes'],
    })
    p_files = [f for f in P.rglob('*') if f.is_file()]
    product = archive(P, 'complete-source-and-originals.tar.gz', p_files)
    save(P, 'roundtrip.json', product)
    save(P, 'manifest.json', {'status': 'FROZEN', 'source_freeze': ident((P / 'source-freeze.json').read_bytes()), 'archive': {k:v for k,v in product.items() if k != 'members'}, 'archive_member_count': len(product['members']), 'members': product['members'], 'exclusions': ['Whole original English/Quiz ZIPs and previously extracted PNGs remain unchanged at the original pack paths; no duplicate archives or images inside this patch pack.']})
    for root in (E, P):
        lines = [f"{ident(f.read_bytes())['sha256']}  {f.relative_to(root)}\n" for f in sorted(root.rglob('*')) if f.is_file()]
        with (root / 'SHA256SUMS').open('x', encoding='utf-8') as stream:
            stream.writelines(lines)
    print(json.dumps({'original_pack': str(E), 'technical_archive': {k:v for k,v in technical.items() if k != 'members'}, 'technical_members': len(technical['members']), 'source_pack': str(P), 'source_archive': {k:v for k,v in product.items() if k != 'members'}, 'source_members': len(product['members']), 'source_manifest': ident((P / 'manifest.json').read_bytes()), 'source_handoff': ident((P / 'handoff.json').read_bytes()), 'new_engine_or_tests': False}, indent=2))


if __name__ == '__main__':
    main()
