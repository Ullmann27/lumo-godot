"""Install the private Godot host inside the generated Flutter Android application."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ANDROID = 'http://schemas.android.com/apk/res/android'
TOOLS = 'http://schemas.android.com/tools'
ET.register_namespace('android', ANDROID)
ET.register_namespace('tools', TOOLS)
START = '// BEGIN LUMO EMBEDDED GODOT'
END = '// END LUMO EMBEDDED GODOT'
BLOCK = '''// BEGIN LUMO EMBEDDED GODOT
android {
    defaultConfig {
        minSdk = 24
        ndk {
            abiFilters.clear()
            // Flutter passes -Psplit-per-abi=true and owns the split filters.
            // Universal builds keep the previous exact two-architecture set.
            if (project.findProperty("split-per-abi") != "true") {
                abiFilters.addAll(listOf("arm64-v8a", "x86_64"))
            }
        }
    }
    androidResources { noCompress += "pck" }
    packaging {
        jniLibs {
            useLegacyPackaging = true
            excludes.addAll(listOf("lib/armeabi-v7a/**", "lib/x86/**"))
        }
    }
}
dependencies {
    implementation("org.godotengine:godot:4.6.3.stable")
}
// These are in-place test updates, not Play Store multi-APK version offsets.
// Keep the committed build number so a later universal APK can still update.
if (project.findProperty("split-per-abi") == "true") {
    // Register after Flutter's configureEach callback, but before AGP freezes
    // outputs. onVariants runs too early; afterEvaluate runs too late.
    android.applicationVariants.configureEach {
        outputs.all {
            @Suppress("DEPRECATION")
            val apkOutput = this as com.android.build.gradle.api.ApkVariantOutput
            apkOutput.versionCodeOverride = flutter.versionCode
        }
    }
    tasks.register("verifyLumoSplitVersionCodes") {
        doLast {
            val expected = flutter.versionCode
            val observedAbis = mutableSetOf<String>()
            val releaseOutputs = android.applicationVariants
                .filter { it.buildType.name == "release" }
                .flatMap { it.outputs }
            check(releaseOutputs.size == 2) { "Expected exactly two release APK outputs" }
            releaseOutputs.forEach { output ->
                @Suppress("DEPRECATION")
                val apkOutput = output as com.android.build.gradle.api.ApkVariantOutput
                @Suppress("DEPRECATION")
                val abi = apkOutput.getFilter(com.android.build.VariantOutput.FilterType.ABI)
                check(abi != null) { "Missing release output ABI" }
                observedAbis.add(abi)
                check(apkOutput.versionCodeOverride == expected) {
                    "Lumo APK version mismatch for $abi: ${apkOutput.versionCodeOverride}, expected $expected"
                }
                println("Lumo split version preflight: $abi = $expected")
            }
            check(observedAbis == setOf("arm64-v8a", "x86_64")) { "Wrong release APK ABI set" }
        }
    }
}
// END LUMO EMBEDDED GODOT'''


def prepare(root: Path):
    main = root / 'android/app/src/main'
    manifest = main / 'AndroidManifest.xml'
    tree = ET.parse(manifest)
    doc = tree.getroot()
    attr = lambda name: f'{{{ANDROID}}}{name}'
    app = doc.find('application')
    if app is None:
        raise ValueError('Missing Android application')
    # The available ANGLE/SwiftShader emulators crash in Flutter's Impeller
    # Vulkan path. Skia GLES also gives this app a compatible graphics path
    # when switching to the embedded Godot GLES engine.
    renderer = next((entry for entry in app.findall('meta-data')
                     if entry.get(attr('name')) == 'io.flutter.embedding.android.EnableImpeller'), None)
    if renderer is None:
        renderer = ET.SubElement(app, 'meta-data')
    renderer.set(attr('name'), 'io.flutter.embedding.android.EnableImpeller')
    renderer.set(attr('value'), 'false')
    for entry in app.findall('provider/meta-data'):
        if entry.get(attr('name')) == 'android.support.FILE_PROVIDER_PATHS':
            entry.set(f'{{{TOOLS}}}replace', 'android:resource')
    gradle = root / 'android/app/build.gradle.kts'
    text = gradle.read_text()
    namespace = re.search(r'namespace\s*=\s*"([^"]+)"', text)
    if namespace is None:
        raise ValueError('Expected the generated Kotlin Android host')
    namespace = namespace.group(1)
    name = namespace + '.LumoGameActivity'
    activity = next((a for a in app.findall('activity') if a.get(attr('name')) == name), None)
    if activity is None:
        activity = ET.SubElement(app, 'activity')
    # Kart is a landscape-only game. Keep the Android host aligned with
    # Godot's SCREEN_SENSOR_LANDSCAPE request so fold/unfold resize events do
    # not start from a contradictory portrait lock.
    for key, value in {
        'name': name, 'exported': 'false', 'process': ':lumo_game',
        'screenOrientation': 'sensorLandscape', 'resizeableActivity': 'true',
        'configChanges': 'orientation|screenSize|smallestScreenSize|keyboardHidden|keyboard|navigation|screenLayout|uiMode|colorMode|density|assetsPaths',
        'theme': '@style/LumoGameTheme', 'enableOnBackInvokedCallback': 'false',
    }.items():
        activity.set(attr(key), value)
    # A visible Cards activity depends on the existing Dart controller in the
    # main process. A private bound service makes that dependency visible to
    # Android's cached-process/freezer policy; it is never a started service.
    service_name = namespace + '.CardsAuthorityService'
    service = next((entry for entry in app.findall('service')
                    if entry.get(attr('name')) == service_name), None)
    if service is None:
        service = ET.SubElement(app, 'service')
    service.set(attr('name'), service_name)
    service.set(attr('exported'), 'false')
    service.attrib.pop(attr('process'), None)
    c4_name = namespace + '.ConnectFourGameActivity'
    c4 = next((a for a in app.findall('activity') if a.get(attr('name')) == c4_name), None)
    if c4 is None:
        c4 = ET.SubElement(app, 'activity')
    c4.attrib.update(activity.attrib)
    c4.set(attr('name'), c4_name)
    c4.set(attr('screenOrientation'), 'sensor')
    c4_service_name = namespace + '.ConnectFourAuthorityService'
    c4_service = next((a for a in app.findall('service') if a.get(attr('name')) == c4_service_name), None)
    if c4_service is None:
        c4_service = ET.SubElement(app, 'service')
    c4_service.set(attr('name'), c4_service_name)
    c4_service.set(attr('exported'), 'false')
    c4_service.attrib.pop(attr('process'), None)
    main_activity = next((a for a in app.findall('activity') if (a.get(attr('name')) or '').endswith('MainActivity')), None)
    if main_activity is not None:
        main_activity.set(attr('resizeableActivity'), 'true')
    queries = doc.find('queries')
    if queries is not None:
        for package in queries.findall('package'):
            if package.get(attr('name')) == 'dev.ullmann.lumo3d':
                queries.remove(package)
    ET.indent(tree)
    tree.write(manifest, encoding='utf-8', xml_declaration=True)
    if START in text:
        if text.count(START) != 1 or text.count(END) != 1:
            raise ValueError('Invalid embedded host markers')
        text = re.sub(re.escape(START) + '.*?' + re.escape(END), lambda _: BLOCK, text, flags=re.S)
    else:
        text = text.rstrip() + '\n\n' + BLOCK + '\n'
    gradle.write_text(text)
    target = main / 'kotlin' / Path(*namespace.split('.'))
    target.mkdir(parents=True, exist_ok=True)
    for filename in ('LumoGameActivity.kt', 'GameEventStore.kt', 'CardsTableBridge.kt', 'CardsAuthorityService.kt', 'ConnectFourBridge.kt', 'ConnectFourAuthorityService.kt', 'ConnectFourGameActivity.kt'):
        source = (root / 'tools/auto_install' / filename).read_text()
        (target / filename).write_text(re.sub(r'^package [^\n]+', f'package {namespace}', source, count=1))
    java_target = main / 'java' / Path(*namespace.split('.'))
    java_target.mkdir(parents=True, exist_ok=True)
    source = (root / 'tools/auto_install/CardsAuthorityRegistry.java').read_text()
    (java_target / 'CardsAuthorityRegistry.java').write_text(
        re.sub(r'^package [^\n]+', f'package {namespace};', source, count=1))
    resources = main / 'res/values'
    resources.mkdir(parents=True, exist_ok=True)
    (resources / 'lumo_game_styles.xml').write_text('''<resources>
    <style name="LumoGameTheme" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="android:windowActionModeOverlay">true</item>
        <item name="android:windowNoTitle">true</item>
        <item name="android:windowBackground">#142D42</item>
    </style>
</resources>
''')
    rules = root / 'android/app/proguard-rules.pro'
    existing = rules.read_text() if rules.exists() else ''
    required_rules = (
        ('C4 Godot methods are reflected in its isolated Activity.',
         '-keep class ' + namespace + '.ConnectFourHostPlugin { *; }'),
        ('Godot registers the host methods through reflection.',
         '-keep class ' + namespace + '.LumoHostPlugin { *; }'),
        # Godot's native library resolves Java classes and callbacks by their
        # original names. Java usage analysis cannot see JNI-only methods such
        # as Godot.restart() and Godot.setKeepScreenOn(boolean).
        ('Godot JNI and reflection require the original engine classes and members.',
         '-keep class org.godotengine.godot.** { *; }'),
        # ML Kit discovers these factories from Android manifest metadata and
        # instantiates them reflectively. R8 otherwise removes their unused
        # public zero-argument constructors, breaking scanner initialization.
        ('ML Kit component discovery requires registrar names, constructors and factories.',
         '-keep class * implements com.google.firebase.components.ComponentRegistrar { *; }'),
    )
    for comment, keep in required_rules:
        if keep not in existing:
            existing = existing.rstrip() + '\n# ' + comment + '\n' + keep + '\n'
    if not rules.exists() or existing != rules.read_text():
        rules.write_text(existing)
    print('Embedded Godot host prepared; same APK, private activity, durable reward events.')


if __name__ == '__main__':
    prepare(Path(__file__).resolve().parents[1])
