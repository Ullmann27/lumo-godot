# Dream-only native workflow handoff

Apply only `v2/final-source/.github/workflows/lumo-dream-connections.yml`. The V2 workflow is the one actually accepted by Actionlint. Its final source hash and single repo path are in `v2/source-freeze.json` and `handoff.json`.

The initial V1 workflow, its freeze and full original red Actionlint streams are preserved in the pack root. That first run rejected two `runner.temp` expressions in job-level env. Root authorized one correction verification: V2 builds the external paths from the real RUNNER_TEMP in a shell step, publishes them through GITHUB_ENV and uses runner.temp only in the allowed artifact step input. V2 Actionlint exited0 with empty stdout/stderr. No third lint or other local test ran.

The workflow accepts only the exact internal Dream push branch, checks out github.sha without persisted credentials, uses read-only repository permissions and has its own concurrency group. It cannot create an APK, release or host pin. The pinned Godot4.6.3 URL/SHA comes from the original f052 Nextgen workflow. Xvfb/Mesa and external Pillow12.3.0 venv serve the real import and renderer gates.

Existing Return21/Wisp14/Treasure92/Learning5347 probes retain60/180/420/420-second limits and exact full-line markers. The separate paired Dream runner adds two120-second and three180-second probes, strict source inventories and seven original PNGs. The45-minute job limit also bounds installation/import/test/upload work; no runtime completion or renderer success is claimed before actual CI.

Original marker logs, source blobs, paired runner contract and unaltered V1/V2 lint streams are retained. Only V2 is an integration candidate. Source tracked dirt and index changes fail; generated untracked UID/import files are preserved and separately inventoried instead of deleted. All final source/log/test/capture evidence is always uploaded, including failure cases.
