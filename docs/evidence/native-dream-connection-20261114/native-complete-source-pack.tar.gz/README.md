# Separate Dream connection on f052

## State

Frozen source proposal for Root's checkpoint. Base: `f052c2795b765265dbb6f5c27b9e92b557d39a39`, tree `35492eec16cac6774bc546b6e57628900bef61cb`. Producer: PR173 `454e81229b0193cba75844e9985a53deb2ce5c91`, tree `ab886683d8bc1ef86f2fff5e154a6dcb654ffb21`. The actual base HEAD, tree, tracked status and index are identical before and after preparation. No repository source, Git index, ref, CI run or Host79/f052 pin was changed.

The final-source directory contains exactly16 paths:13 original published Producer files and3 new isolated Dream gate files. The three modified production hooks are exact original hunks on f052 and result in the published454e blobs. Binary-complete integration.patch uses ordinary a/path and b/path headers; source-freeze.json is the authoritative file/mode/blob/hash map.

## Original assets and provenance

Both GLBs were retrieved once using the connector's explicitly supported `github_fetch_file(..., encoding="base64")` at the fixed published head. The serialized complete connector responses are preserved under originals/. Their decoded bytes match both the Git blob identities and the published provenance SHA256/lengths. The JSON/BIN chunk layout, all43 actual accessors, triangle indices, mesh/material/node/scene references and named moving parts were checked. There are no external buffer/image/texture dependencies. Storybook:115136 bytes,5156 triangles,7 surfaces,7 meshes. Blossom:115408 bytes,6884 triangles,9 surfaces,6 meshes. Both have5 materials and0 textures.

This was binary/source inspection, not a Godot import or visual review. inspect_glb_originals.py and glb-validation.json preserve the exact check. The original provenance.json is part of final-source; the exact authoring generator and original producer runner are retained only in producer-reference. Blender .blend design payloads were not downloaded or added, and Blender is not a runtime/build dependency of these self-contained GLBs.

## Runner contract

Run `bash tools/validate_dream_connections.sh` from the new native checkout. GODOT_BIN may select the exact Godot4.6.3 binary. LUMO_DREAM_LOG_DIR must name a new, nonexistent output directory; its parent may already exist. If omitted, mktemp chooses a directory outside the checkout. LUMO_EXPECTED_NATIVE_SHA may bind the caller's exact new native pin.

The five calls are the original Ambience170 and Garden544 headless probes at120 seconds each, the Treasure and Learning ambience captures, and the three-size Garden capture at180 seconds each. Their aggregate hard probe budget is780 seconds; the unchanged run_godot_probe.py has up to5 seconds of termination grace per interrupted child. Setup, import, source hashing and raster decoding are additional job work. DISPLAY or xvfb-run is required for all rendered calls. There is no headless renderer substitution and no extra Wisp/Return/52-mode invocation in this runner.

Outputs include five complete logs, exact ordered results.tsv, source SHA/tree/clean stamps before and after, engine.txt, capture-root.txt, and source-inventory-before.json/source-inventory-after.json. Source inventories hash the actual Git index and every materialized tracked file, verify its Git blob and executable mode, and allow absence only for explicit sparse entries. The before/after tracked list and index must agree. Untracked UID/import metadata is inventoried with its tracked owner and original hashes separately from other untracked files. These files are not treated as tracked dirt, silently removed or cleaned. The Godot cache itself is not copied into that inventory.

The separate verify_dream_rasters.py reopens and fully decodes all7 PNGs, rejects uniform/invisible/wrong-size/missing/extra images, binds the2 original JSON reports to the correct scenes and capture paths, requires exact high-quality ambience counts, and verifies both advancing clocks and actual changed pixel values. Garden dimensions remain1280x720,412x915,2400x1080. Ambience pair dimensions are taken from actual equal-size original reports, with finite bounded decode sizes. All five exact success lines must occur once, and engine errors/resource leaks still reject the collection.

Collection writes dream-images.json using `python3 tools/verify_dream_rasters.py "$LUMO_DREAM_LOG_DIR" --write`. `verify(root, write=False)` recomputes without writing. The default CLI without --write also compares the stored manifest to the recomputation. Absolute original report paths are checked against capture-root.txt while file reads use fixed relative paths, so a downloaded artifact can be rechecked after relocation.

Final markers:

- `[DreamRasterRoster] PASS 7 actual PNG files and 2 original reports`
- `[LumoDreamConnections] PASS 5 original probes and 7 verified renderer PNGs`

## Preserved boundaries and remaining work

The current Wisp implementation, C4 return, learning product,52-mode runner,17-raster helper/tests, settlement/village work and Host pin remain untouched. The Producer's full nine-call wrapper is not installed: among other differences it expects rendered Wisp18, while our current Wisp probe has14 checks. Dream adds only its own five calls/seven PNGs.

The12 focused synthetic reader methods are delivered as unexecuted source. No new contract/syntax/engine/render/device tests were run before the Root checkpoint. After publication, the new contract tests and two original Dream headless probes still need execution; real seven-image renderer proof and direct visual review remain outstanding. The existing saved454e CI list is empty and is not presented as combined acceptance. The prior f052 headless and blocked local renderer evidence remains a separate immutable historical pack.

Required existing tools: bash, Git, Python3/Pillow, unchanged tools/run_godot_probe.py, an imported Godot4.6.3 project and a real display or Xvfb for rendering. No new SDK, textures, app rebuild or Renderer retry was performed here.
