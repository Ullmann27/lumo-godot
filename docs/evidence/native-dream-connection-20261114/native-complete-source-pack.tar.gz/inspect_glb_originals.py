#!/usr/bin/env python3
"""Inspect the two fixed published GLBs without invoking an engine or renderer."""
from pathlib import Path
import hashlib
import json
import math
import struct

ROOT = Path(__file__).resolve().parent
FORMATS = {5120: ('b', 1), 5121: ('B', 1), 5122: ('h', 2),
           5123: ('H', 2), 5125: ('I', 4), 5126: ('f', 4)}
WIDTHS = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4,
          'MAT2': 4, 'MAT3': 9, 'MAT4': 16}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value, minimum=0):
    return type(value) is int and value >= minimum


def inspect(path, declared):
    raw = path.read_bytes()
    require(len(raw) == declared['bytes'], 'Published byte count mismatch')
    digest = hashlib.sha256(raw).hexdigest()
    require(digest == declared['sha256'], 'Published SHA256 mismatch')
    magic, version, length = struct.unpack_from('<4sII', raw)
    require((magic, version, length) == (b'glTF', 2, len(raw)), 'Invalid GLB2 header')
    chunks = []
    offset = 12
    while offset < len(raw):
        require(offset + 8 <= len(raw), 'Truncated chunk header')
        size, kind = struct.unpack_from('<II', raw, offset)
        require(size % 4 == 0 and offset + 8 + size <= len(raw), 'Invalid chunk extent')
        chunks.append((kind, raw[offset + 8:offset + 8 + size]))
        offset += 8 + size
    require(offset == len(raw), 'Trailing bytes')
    require([kind for kind, _ in chunks] == [0x4E4F534A, 0x004E4942], 'Expected JSON and BIN chunks')
    doc = json.loads(chunks[0][1].decode('utf-8'))
    binary = chunks[1][1]
    require(doc['asset']['version'] == '2.0', 'Unsupported glTF asset')
    require(not doc.get('extensionsRequired'), 'Unexpected required extensions')
    require(len(doc['buffers']) == 1, 'Expected one embedded buffer')
    buffer = doc['buffers'][0]
    require('uri' not in buffer, 'External buffer URI')
    require(integer(buffer['byteLength']) and 0 <= len(binary) - buffer['byteLength'] <= 3,
            'Embedded buffer length mismatch')
    require(not doc.get('images') and not doc.get('textures'), 'Unexpected texture dependency')
    views = doc.get('bufferViews', [])
    for view in views:
        require(view['buffer'] == 0 and type(view['buffer']) is int, 'Invalid buffer reference')
        start, size = view.get('byteOffset', 0), view['byteLength']
        require(integer(start) and integer(size, 1) and start + size <= buffer['byteLength'],
                'Buffer view outside BIN')
    accessors = doc.get('accessors', [])
    values = []
    for accessor in accessors:
        require('sparse' not in accessor, 'Unexpected sparse accessor')
        ref = accessor['bufferView']
        require(integer(ref) and ref < len(views), 'Invalid accessor view')
        require(accessor['componentType'] in FORMATS and accessor['type'] in WIDTHS,
                'Unsupported accessor encoding')
        fmt, size = FORMATS[accessor['componentType']]
        width = WIDTHS[accessor['type']]
        item_size = size * width
        count = accessor['count']
        offset = accessor.get('byteOffset', 0)
        view = views[ref]
        stride = view.get('byteStride', item_size)
        require(integer(count, 1) and integer(offset) and integer(stride, item_size),
                'Invalid accessor shape')
        require(stride % size == 0 and offset % size == 0, 'Misaligned accessor')
        require(offset + (count - 1) * stride + item_size <= view['byteLength'],
                'Accessor outside view')
        start = view.get('byteOffset', 0) + offset
        rows = [struct.unpack_from('<' + fmt * width, binary, start + i * stride)
                for i in range(count)]
        require(all(math.isfinite(x) for row in rows for x in row), 'Nonfinite geometry data')
        values.append(rows)
    materials = doc.get('materials', [])
    for material in materials:
        require(material.get('alphaMode', 'OPAQUE') == 'OPAQUE', 'Unexpected transparent material')
    surfaces = triangles = 0
    for mesh in doc.get('meshes', []):
        for primitive in mesh['primitives']:
            surfaces += 1
            require(primitive.get('mode', 4) == 4, 'Unexpected non-triangle primitive')
            require('POSITION' in primitive['attributes'], 'Missing vertex positions')
            for ref in primitive['attributes'].values():
                require(integer(ref) and ref < len(accessors), 'Invalid attribute accessor')
            position_ref = primitive['attributes']['POSITION']
            require(accessors[position_ref]['type'] == 'VEC3' and
                    accessors[position_ref]['componentType'] == 5126, 'Invalid vertex format')
            count = accessors[position_ref]['count']
            require(all(accessors[ref]['count'] == count for ref in primitive['attributes'].values()),
                    'Attribute count mismatch')
            material_ref = primitive['material']
            require(integer(material_ref) and material_ref < len(materials), 'Invalid material reference')
            if 'indices' in primitive:
                ref = primitive['indices']
                require(integer(ref) and ref < len(accessors), 'Invalid indices reference')
                require(accessors[ref]['type'] == 'SCALAR' and
                        accessors[ref]['componentType'] in (5121, 5123, 5125), 'Invalid index encoding')
                indices = [row[0] for row in values[ref]]
                require(all(index < count for index in indices), 'Vertex index outside mesh')
                count = len(indices)
            require(count % 3 == 0, 'Incomplete triangle')
            triangles += count // 3
    nodes = doc.get('nodes', [])
    parents = {}
    for index, node in enumerate(nodes):
        if 'mesh' in node:
            require(integer(node['mesh']) and node['mesh'] < len(doc['meshes']), 'Invalid node mesh')
        for key, size in [('matrix', 16), ('translation', 3), ('rotation', 4), ('scale', 3)]:
            if key in node:
                require(len(node[key]) == size and
                        all(type(x) in (int, float) and math.isfinite(x) for x in node[key]),
                        'Invalid node transform')
        for child in node.get('children', []):
            require(integer(child) and child < len(nodes) and child != index and child not in parents,
                    'Invalid or shared child node')
            parents[child] = index
    for index in range(len(nodes)):
        seen = set()
        current = index
        while current in parents:
            require(current not in seen, 'Node cycle')
            seen.add(current)
            current = parents[current]
    scenes = doc.get('scenes', [])
    require(integer(doc.get('scene')) and doc['scene'] < len(scenes), 'Invalid default scene')
    for scene in scenes:
        for node in scene.get('nodes', []):
            require(integer(node) and node < len(nodes) and node not in parents, 'Invalid scene root')
    names = {node.get('name') for node in nodes}
    require(set(declared['animated_part_names']) <= names, 'Missing named moving geometry')
    actual = {'triangles': triangles, 'surfaces': surfaces, 'mesh_count': len(doc['meshes']),
              'material_count': len(materials), 'texture_count': len(doc.get('textures', []))}
    require(all(actual[k] == declared[k] for k in actual), 'Provenance geometry counts disagree')
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': digest,
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
            'glb_version': version, 'chunks': [{'type': kind, 'bytes': len(data)} for kind, data in chunks],
            'accessors_fully_read': len(accessors), 'buffer_views': len(views),
            'nodes': len(nodes), 'scenes': len(scenes), 'embedded_only': True,
            'geometry': actual, 'animated_part_names': declared['animated_part_names'],
            'engine_imported': False, 'rendered': False, 'visual_review': False}


def main():
    directory = ROOT / 'final-source/assets/dream_garden'
    provenance = json.loads((directory / 'provenance.json').read_bytes())
    report = {'schema': 1, 'scope': 'Original GLB byte, chunk, geometry and internal-reference validation only',
              'assets': [inspect(directory / item['file'], item) for item in provenance['assets']]}
    (ROOT / 'glb-validation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
