#!/usr/bin/env python3
"""Assemble only the authorized Native34 source entries, without touching a checkout."""
from __future__ import annotations

import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

WORKSPACE = Path('/workspace/scratch/b3485b7bb989')
PACK = WORKSPACE / 'native182-29080-integration-2281-20261114'
PLAN_ROOT = WORKSPACE / 'native182-29080-readonly-followup-20261114'
NATIVE = WORKSPACE / 'native2281-packaging-export-20261114/checkout-after'
HOST = Path('/tmp/lumo-root-recovery-1242/host')
BASE = '2281d990fb584db6f2cf786da8fec3badc2d9585'
BASE_TREE = 'd7e0128afbda641cb92e29c41a8839d901ef5b43'
PRODUCER = '29080ef8cd1a5b385eeeec97976fbefd31280427'
PRODUCER_TREE = '5ddbea2b1d5e76ed592a27c36079632d7f26cada'
ENV = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0', 'GIT_NO_LAZY_FETCH': '1'}


def ident(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo, env=ENV)


def put(relative, raw):
    if isinstance(raw, str):
        raw = raw.encode('utf-8')
    path = PACK / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as handle:
        handle.write(raw)
    assert path.read_bytes() == raw
    return {'path': relative, **ident(raw)}


def js(relative, value):
    return put(relative, json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def functions(text):
    starts = list(re.finditer(r'^(?:static )?func ([A-Za-z_]\w*)\b', text, re.MULTILINE))
    assert starts
    result = {}
    for index, match in enumerate(starts):
        stop = starts[index + 1].start() if index + 1 < len(starts) else len(text)
        assert match.group(1) not in result
        result[match.group(1)] = text[match.start():stop]
    return text[:starts[0].start()], result


def replace_once(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new, 1)


def merge_bridge(target, producer, ancestor):
    final = replace_once(target,
        '"cards", "connect_four", "games", "home"]:',
        '"cards", "connect_four", "memory", "quiz", "games", "home"]:')
    final = replace_once(final,
        'not in ["Mathematik", "Deutsch", "Sachunterricht", "Logik"]',
        'not in ["Mathematik", "Deutsch", "Sachunterricht", "Englisch", "Logik"]')
    restored = replace_once(final, '"connect_four", "memory", "quiz", "games"',
                            '"connect_four", "games"')
    restored = replace_once(restored, '"Sachunterricht", "Englisch", "Logik"',
                            '"Sachunterricht", "Logik"')
    assert restored == target
    bp, bf = functions(ancestor)
    tp, tf = functions(target)
    pp, pf = functions(producer)
    fp, ff = functions(final)
    assert bp == tp == pp == fp
    assert list(bf) == list(tf) == list(pf) == list(ff)
    checks = []
    for name in ff:
        if name != 'validated_options':
            assert ff[name] == tf[name] == pf[name] == bf[name]
        checks.append({'function': name, 'target': ident(tf[name].encode()),
            'producer': ident(pf[name].encode()), 'final': ident(ff[name].encode()),
            'disposition': 'two exact allowlist additions, full target Village branch retained' if name == 'validated_options'
                           else 'byte-identical across base, target, producer and final'})
    return final, checks


def merge_learning(target, producer, ancestor):
    bp, bf = functions(ancestor)
    tp, tf = functions(target)
    pp, pf = functions(producer)
    assert set(bf) <= set(tf) and set(bf) <= set(pf)
    assert set(tf) == set(bf)
    prefix = replace_once(tp,
        'const ATELIER = preload("res://scripts/learning/learning_atelier.gd")\n',
        'const ATELIER = preload("res://scripts/learning/learning_atelier.gd")\n'
        'const ENGLISH_GALLERY = preload("res://scripts/learning/english_object_gallery.gd")\n')
    voice = 'var voice_button: Button\n'
    assert bp.count(voice) == tp.count(voice) == pp.count(voice) == 1
    original_tail = bp.split(voice, 1)[1]
    producer_tail = pp.split(voice, 1)[1]
    assert tp.split(voice, 1)[1] == original_tail
    prefix = replace_once(prefix, voice + original_tail, voice + producer_tail)
    final_functions = {}
    checks = []
    overlaps = []
    for name, ours in tf.items():
        old, theirs = bf[name], pf[name]
        if theirs == old:
            merged = ours
            disposition = 'target-only change retained' if ours != old else 'unchanged'
        elif ours == old:
            merged = theirs
            disposition = 'exact published producer function'
        else:
            overlaps.append(name)
            if name == '_build_stage':
                anchor = '\tcamera.look_at(Vector3(0.0, 0.7, 0.0))\n'
                wonder = ('\twonder = WISPS.new()\n'
                          '\twonder.name = "LearningWonder"\n'
                          '\twonder.celebration_only = true\n'
                          '\twonder.set_reduced_motion(reduced_motion)\n'
                          '\tadd_child(wonder)\n')
                assert ours == replace_once(old, anchor, anchor + wonder)
                merged = replace_once(theirs, anchor, anchor + wonder)
                assert merged.replace(wonder, '', 1) == theirs
                without_english = replace_once(merged,
                    '\t_atelier = ATELIER.new()\n\tadd_child(_atelier)\n',
                    '\tadd_child(ATELIER.new())\n')
                english = ('\tif activity.kind == "english_objects":\n'
                           '\t\t# Keep every existing atelier mesh behind the fitted object gallery.\n'
                           '\t\t# Orthographic translation along view depth preserves its screen position.\n'
                           '\t\t_atelier.position = -camera.global_basis.z * 24.0\n'
                           '\t\tcamera.far = 100.0\n')
                without_english = replace_once(without_english, english, '')
                assert without_english == ours
                disposition = 'exact target Wisp construction plus exact producer Atelier handle and English camera-depth branch'
            elif name == '_notification':
                merged = replace_once(theirs, '\t\tsuspended = true\n',
                    '\t\tsuspended = true\n\t\twonder.set_paused(true)\n')
                merged = replace_once(merged, '\t\tsuspended = false\n',
                    '\t\tsuspended = false\n\t\twonder.set_paused(false)\n')
                assert merged.replace('\t\t_mark_learning_observation()\n', '') == ours
                no_wisp = merged.replace('\t\twonder.set_paused(true)\n', '').replace('\t\twonder.set_paused(false)\n', '')
                assert no_wisp == theirs
                disposition = 'target Wisp pause/resume before exact producer observation invalidation; no lifecycle branch removed'
            else:
                raise ValueError('Unexpected source overlap: ' + name)
        final_functions[name] = merged
        checks.append({'function': name, 'base': ident(old.encode()), 'target': ident(ours.encode()),
            'producer': ident(theirs.encode()), 'final': ident(merged.encode()), 'disposition': disposition})
    assert overlaps == ['_build_stage', '_notification']
    for name, text in pf.items():
        if name not in bf:
            final_functions[name] = text
            checks.append({'function': name, 'producer': ident(text.encode()), 'final': ident(text.encode()),
                           'disposition': 'new exact published producer function'})
    for name in ('move_token', '_inspect', '_give_water', '_give_sun', '_return_to_lesson',
                 '_queue_narration', '_stop_speech', '_tick_speech'):
        assert final_functions[name] == tf[name], name
    final = prefix + ''.join(final_functions.values())
    assert final.count('const WISPS =') == final.count('const ENGLISH_GALLERY =') == 1
    assert final.count('\twonder = WISPS.new()') == 1
    return final, checks


def checkout_identity():
    index = Path(git(NATIVE, 'rev-parse', '--git-path', 'index').decode().strip())
    if not index.is_absolute():
        index = NATIVE / index
    return {'head': git(NATIVE, 'rev-parse', 'HEAD').decode().strip(),
            'tree': git(NATIVE, 'rev-parse', 'HEAD^{tree}').decode().strip(),
            'tracked_status': git(NATIVE, 'status', '--porcelain', '--untracked-files=no').decode(),
            'index': ident(index.read_bytes())}


def main():
    PACK.mkdir()
    plan_raw = (PLAN_ROOT / 'connection-plan-2281.json').read_bytes()
    assert hashlib.sha256(plan_raw).hexdigest() == '2bba9bcbdf24570c3102abf3c94c2c0e5ba5e9232dc4c6f50e40270c0042ca30'
    plan = json.loads(plan_raw)
    put('originals/connection-plan-2281.json', plan_raw)
    put('originals/plan-freeze.json', (PLAN_ROOT / 'plan-freeze.json').read_bytes())
    tree_raw = (PLAN_ROOT / 'originals/head-tree.json').read_bytes()
    producer_tree = json.loads(tree_raw)
    assert producer_tree['sha'] == PRODUCER_TREE and producer_tree['truncated'] is False
    producer_entries = {row['path']: row for row in producer_tree['tree'] if row['type'] == 'blob'}
    put('originals/producer-head-tree.json', tree_raw)
    put('originals/producer-head-commit.json', (PLAN_ROOT / 'originals/head.json').read_bytes())
    put('originals/producer-47ca-to-29080-delta.json', (PLAN_ROOT / 'originals/delta.json').read_bytes())
    before = checkout_identity()
    assert before['head'] == BASE and before['tree'] == BASE_TREE and before['tracked_status'] == ''
    js('base-checkout-before.json', before)
    base_raw = git(NATIVE, 'ls-tree', '-rz', '--full-tree', BASE)
    put('originals/target-tree-index.raw', base_raw)
    base_entries = {}
    for raw in base_raw.split(b'\0'):
        if not raw:
            continue
        metadata, filename = raw.split(b'\t', 1)
        mode, kind, blob = metadata.decode().split()
        assert kind == 'blob'
        base_entries[filename.decode()] = {'mode': mode, 'git_blob': blob}
    commit = git(NATIVE, 'cat-file', 'commit', BASE)
    assert hashlib.sha1(b'commit ' + str(len(commit)).encode() + b'\0' + commit).hexdigest() == BASE
    put('originals/target-commit.raw', commit)
    entries, merges, all_patch, merge_patch, producer_patch = [], {}, [], [], []
    for row in plan['selected_paths']:
        name = row['path']
        published = producer_entries[name]
        assert published['sha'] == row['producer_blob'] and published['mode'] == row['producer_mode']
        old = git(NATIVE, 'show', BASE + ':' + name) if name in base_entries else None
        if old is not None:
            expected = row['target_2281']
            assert ident(old) == {key: expected[key] for key in ('bytes', 'sha256', 'git_blob')}
            assert base_entries[name]['mode'] == expected['mode']
            assert (NATIVE / name).read_bytes() == old
            put('before/' + name, old)
        if name.endswith('.png'):
            raw = git(HOST, 'cat-file', 'blob', row['producer_blob'])
            identity = ident(raw)
            assert identity['git_blob'] == published['sha'] and identity['bytes'] == published['size']
            assert git(HOST, 'rev-parse', '0b7bacadd3cdc45d22a8e038c5df50ba8b739d62:' + row['same_original_host_path']).decode().strip() == published['sha']
            entries.append({'path': name, 'mode': published['mode'], **identity,
                'source_path': None, 'source_kind': 'existing_native_blob_reference',
                'producer_head': PRODUCER, 'producer_blob': published['sha'],
                'original_host_path': row['same_original_host_path'],
                'original_host_source': '0b7bacadd3cdc45d22a8e038c5df50ba8b739d62',
                'materialized': False, 'no_image_transformation_or_visual_review': True})
            continue
        original = Path(row['materialized_original']['path']).read_bytes()
        identity = ident(original)
        assert identity['git_blob'] == published['sha'] and identity['bytes'] == published['size']
        assert identity == {key: row['materialized_original'][key] for key in ('bytes', 'sha256', 'git_blob')}
        put('original-source/' + name, original)
        final = original
        if row['disposition'] == 'native_three_way_review_required':
            ancestor_path = WORKSPACE / 'native-pr182-selective-readonly-review-20261114/read-only-sources/base' / name
            ancestor = ancestor_path.read_bytes()
            assert ident(ancestor)['git_blob'] == row['producer_base_blob']
            put('common-base/' + name, ancestor)
            merger = merge_bridge if name == 'scripts/systems/host_bridge.gd' else merge_learning
            text, proof = merger(old.decode(), original.decode(), ancestor.decode())
            final = text.encode()
            merges[name] = {'base': ident(ancestor), 'target': ident(old), 'producer': ident(original),
                            'final': ident(final), 'functions': proof}
            merge_patch.extend(difflib.unified_diff(old.decode().splitlines(True), text.splitlines(True),
                                                  fromfile='a/' + name, tofile='b/' + name))
            producer_patch.extend(difflib.unified_diff(original.decode().splitlines(True), text.splitlines(True),
                                                     fromfile='producer/' + name, tofile='merged/' + name))
        put('final-source/' + name, final)
        entries.append({'path': name, 'mode': published['mode'], **ident(final),
            'source_path': str(PACK / 'final-source' / name),
            'source_kind': 'merged_source_blob' if final != original else 'existing_native_blob_reference',
            'producer_head': PRODUCER, 'producer_blob': published['sha'], 'materialized': True,
            'base_blob': ident(old)['git_blob'] if old is not None else None,
            'original_source_path': str(PACK / 'original-source' / name)})
        all_patch.extend(difflib.unified_diff((old or b'').decode().splitlines(True), final.decode().splitlines(True),
                                            fromfile='a/' + name if old is not None else '/dev/null', tofile='b/' + name))
    assert len(entries) == 34 and len({row['path'] for row in entries}) == 34
    assert sum(row['materialized'] for row in entries) == 21
    assert sum(row['source_kind'] == 'merged_source_blob' for row in entries) == 2
    put('integration-text.patch', ''.join(all_patch))
    put('merges-only.patch', ''.join(merge_patch))
    put('merged-vs-producer.patch', ''.join(producer_patch))
    js('three-way-merge-provenance.json', merges)
    selected_names = {row['path'] for row in entries}
    protected = []
    for row in plan['protected_target_paths']:
        name, expected = row['path'], row['target']
        assert name not in selected_names
        raw = git(NATIVE, 'show', BASE + ':' + name)
        actual = ident(raw)
        assert actual == {key: expected[key] for key in ('bytes', 'sha256', 'git_blob')}
        assert base_entries[name]['mode'] == expected['mode']
        assert (NATIVE / name).read_bytes() == raw
        protected.append({'path': name, 'mode': expected['mode'], **actual, 'unchanged': True})
    assert len(protected) == 35
    js('protected-target-paths.json', {'target': BASE, 'tree': BASE_TREE, 'paths': protected})
    mapping = dict(base_entries)
    for row in entries:
        mapping[row['path']] = {'mode': row['mode'], 'git_blob': row['git_blob']}
    dependencies, unresolved = [], []
    for row in entries:
        if not row['materialized']:
            continue
        text = Path(row['source_path']).read_text()
        for match in re.finditer(r'[\"\'](res://[^\"\'\n]+)[\"\']', text):
            value = match.group(1)[6:]
            if value in mapping:
                kind = 'exact_file'
            elif value.endswith('/') and any(name.startswith(value) for name in mapping):
                kind = 'existing_directory_prefix'
            elif any(token in value for token in ('%', '{', '*')):
                kind = 'dynamic_resource_expression'
            else:
                kind = 'unresolved_literal'
                unresolved.append({'source': row['path'], 'resource': value})
            dependencies.append({'source': row['path'], 'resource': value, 'kind': kind,
                                 'target': mapping.get(value)})
    js('resource-dependency-binding.json', {'direct_literal_resources': dependencies,
        'unresolved': unresolved, 'scope': 'Static exact resource names and directory prefixes only; no engine/import/parse run.'})
    js('publication-source-map.json', {'repository': 'Ullmann27/lumo-godot', 'parent': BASE, 'base_tree': BASE_TREE,
        'producer_head': PRODUCER, 'producer_tree': PRODUCER_TREE,
        'source_count': len(entries), 'entries': entries,
        'unchanged_base_entries': len(base_entries) - sum(name in base_entries for name in selected_names),
        'new_entries': sum(name not in base_entries for name in selected_names),
        'modified_existing_entries': sum(name in base_entries for name in selected_names),
        'remote_mutations_performed': False, 'tests_or_engine_runs_performed': False})
    after = checkout_identity()
    js('base-checkout-after.json', after)
    assert before == after
    js('source-freeze.json', {'schema': 1, 'status': 'FROZEN_SOURCE_ONLY_BEFORE_CHECKPOINT_TESTS',
        'parent': BASE, 'base_tree': BASE_TREE, 'producer_head': PRODUCER, 'producer_tree': PRODUCER_TREE,
        'source_count': 34, 'materialized_text_sources': 21, 'existing_asset_blob_references': 13,
        'existing_published_final_blobs': 32, 'merged_final_blobs': 2,
        'sources': entries, 'protected_target_paths': protected,
        'base_checkout_index_status_unchanged': True,
        'resource_unresolved_literals': unresolved,
        'limits': ['No source checkout, index, ref, workflow, version or pin was changed.',
            'No test, engine/import, renderer, Android or new combined-source result is claimed.',
            'Producer workflows and test_nextgen_runner/validate_studio are not copied.',
            'Actual29080 authority tests pair Host50503, not the current integrated Host.',
            'Current52/17,Dream,Discovery,Village/Mobile/Wisp/C4-return and2281 notice packaging remain required on the future combined source.']})
    print(json.dumps({'pack': str(PACK), 'source_freeze': ident((PACK / 'source-freeze.json').read_bytes()),
        'merged': {name: proof['final'] for name, proof in merges.items()},
        'unresolved_literals': unresolved}, indent=2))


if __name__ == '__main__':
    main()
