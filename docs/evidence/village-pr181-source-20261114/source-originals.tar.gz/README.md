# PR181: schmaler Dorfanschluss auf c300

Vier unveränderte veröffentlichte Producer-Blobs werden als genaue, konfliktfreie Hunks auf c300 vorbereitet. Drei vorhandene Dateien werden geändert, ein ursprünglicher Skalierungsvertrag kommt hinzu. Alle anderen 3.660 bestehenden Tree-Einträge bleiben erhalten. Das ausschließlich aus vier Quellen gebildete Ergebnis hat den rechnerischen Tree c0c424c35ddb3149d1a8d7ba611d09c9014572cb. Es wurde kein Gitobjekt oder Ref erzeugt.

Die Save-Korrektur bindet die Wiederherstellung des Dorfledgers an den bereits validierten äußeren Versionsumschlag. Der separate Darstellungsanschluss begrenzt detaillierte Gebäude und Collider, folgt Kamera bzw. Explorer und stellt entfernte Gebäude in höchstens vier MultiMesh-Gruppen dar. Das vollständige Modell, alle Save-/ACK-/Host-Rückkehrpfade, Korn, die aktuelle Parent-Ambience, C4/Return, Treasure/Wisp sowie52/17- und Dream-/Discovery-Gates bleiben erhalten.

`integration.patch` enthält die exakten Originalhunks gegen die tatsächlichen c300-Basisblobs. Jeder Kontext, jede alte Zeile und jede Hunklänge wurde ohne Fuzz geprüft; das Ergebnis ist mit den vollständigen vier veröffentlichten Dateien identisch. `exact-patch-application.json` und `protected-source-binding.json` beschreiben den Quellenvergleich. `source-review.json` ist die eigene Integrationsanalyse, keine unabhängige Freigabe.

Die aktuelle be58-Workflowliste meldet drei erfolgreiche Workflows auf genau diesem Producer-Head. Aus den API-Abschlüssen wird kein neuer kombinierter Runtime-,42/46-Scaling-,Bild-,Android- oder60FPS-Nachweis abgeleitet. Vor der nächsten Quellenveröffentlichung wurden keine Tests ausgeführt. Der neue Skalierungsvertrag benötigt einen separat zugewiesenen aktiven Gateanschluss; der bestehende52er-Runner wird hier nicht geändert.

PR167/34421 enthält separat eine TreasureTitleContrast-Deadlinekorrektur600→900 in seinem Studio-Runner. Unser aktueller52er-Runner hat weiterhin600. Dieser Befund ist gemeldet, aber keine Budgetänderung ist Bestandteil dieses Dorfpacks.

Die Ausführungsumgebung ist während der Vorbereitung nicht verfügbar. Alle Inhalte sind vollständig im Funktionsstore erhalten; eine lokale Dateimaterialisierung wird noch nicht behauptet. Root besitzt sämtliche Git-/Pin-/CI-Änderungen.
