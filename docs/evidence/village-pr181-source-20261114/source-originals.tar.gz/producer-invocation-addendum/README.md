# PR181 invocation addendum

This addendum preserves the newly read original producer job and workflow without changing the frozen four-source integration pack.

Run 43588464614, attempt 1, job 132427908321 actually checked out a0e11ac03245d164e09db8825c6f2fd2cb74f878. The original Git API object confirms exactly the same tree faffacb93be479c3b8d3534cc056370c69e1407e as published PR181 head be58fe0afcbbd8bf982592d05d83f0e7742e8934.

The full original job records the economy command with timeout 300 and one actual Engine result `[VillageEconomy] PASS 339 checks`. Its later duplicate is the workflow's grep echo, not another Engine invocation. Our existing combined 52-mode runner retains its separate 420-second economy budget.

Scaling source defines the headless and capture argument tails, LUMO_CAPTURE_DIR, two 1280×720 PNGs, and the 42/46 marker paths. No original local Scaling argv or runtime log is available in the retrieved evidence. The published PR/commit's references to e369facf/8873683 returned API 422, and the current producer CI job does not run Scaling. Those source and author-declared facts do not establish a new combined runtime pass.

All stored raw source/API/log strings are unchanged. No engine, test, source, Git, pin, ref, workflow or CI mutation was performed. The separate TitleContrast timeout follow-up remains outside this pack.
