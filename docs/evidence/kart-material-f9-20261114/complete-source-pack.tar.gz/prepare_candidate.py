from __future__ import annotations

import collections
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


ROOT = Path(__file__).resolve().parent
ORIGINAL = Path('/tmp/native-pr183-184-integration-f9-20261114')
BASE_SHA = 'f9d9772bb932d7ee8702eeb5bca6d98c286f3b98'
BASE_TREE = '4036a20ab80de78bcdf0d074b585be88c2946492'
PRODUCER = '46bf4798d8b8411ef0855faa65180360258103dd'
SELECTED = [
    'scripts/games/kart_vehicle.gd',
    'scripts/games/kart_coachwork_finish.gd',
    'scripts/games/kart_modular_aero_kit.gd',
    'scripts/games/kart_rival_character_finish.gd',
    'scripts/games/kart_rival_model_contract.gd',
    'scripts/games/kart_rival_visual_adapter.gd',
    'scripts/games/lumo_opponent_roster.gd',
    'scripts/tests/kart_fox_eye_proportions_regression.gd',
    'scripts/tests/kart_rival_finish_regression.gd',
    'scripts/tests/kart_rival_visual_adapter_regression.gd',
]
MATERIAL_PATH = 'scripts/games/kart_modular_aero_kit.gd'
REPLACEMENTS = [
    ('core.material_override = kart._mat(accent, 0.0, 0.26, 0.5)',
     'core.material_override = kart._mat(accent, 0.35, 0.26, 0.75)'),
    ('stripe.material_override = kart._mat(accent, 0.35, 0.26, 0.65)',
     'stripe.material_override = kart._mat(accent, 0.35, 0.26, 0.75)'),
]


def identity(data: bytes) -> dict:
    return {
        'bytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest(),
        'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
    }


def write_json(rel: str, value: object) -> None:
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def put(rel: str, data: bytes) -> None:
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_bytes(data)
    assert path.read_bytes() == data


def function_blocks(text: str) -> dict[str, bytes]:
    matches = list(re.finditer(r'^(?:static )?func ([A-Za-z_][A-Za-z_0-9]*)\(', text, re.M))
    return {m.group(1): text[m.start():matches[i + 1].start() if i + 1 < len(matches) else len(text)].encode()
            for i, m in enumerate(matches)}


base = json.loads((ORIGINAL / 'originals/f9-tree-binding.json').read_bytes())
assert base['head'] == BASE_SHA and base['tree'] == BASE_TREE and base['entry_count'] == 3757
head = json.loads((ORIGINAL / 'originals/producer184-tree.original.json').read_bytes())
assert head['sha'] == '08cb90c7a526197fad717b4d428d2232409108f5' and not head['truncated']
head_entries = {r['path']: r for r in head['tree'] if r['type'] == 'blob'}
classification = json.loads((ORIGINAL / 'path-classification.json').read_bytes())
assert len(classification) == 48
assert collections.Counter(r['classification'] for r in classification) == {'new': 28, 'same_preimage': 20}
rows = {r['path']: r for r in classification}

# This reads a private sparse reader checkout; no checkout, index refresh or Git write.
env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1')
checkout = base['source_checkout']
git_commands = [
    ['git', '-C', checkout, 'rev-parse', 'HEAD'],
    ['git', '-C', checkout, 'rev-parse', 'HEAD^{tree}'],
    ['git', '-C', checkout, 'ls-files', '--stage', '-z'],
    ['git', '-C', checkout, 'ls-tree', '-r', '--full-tree', '-z', BASE_SHA],
    ['git', '-C', checkout, 'status', '--porcelain=v1', '--untracked-files=no'],
]
snapshots = []
for phase in ['before']:
    records = []
    for i, argv in enumerate(git_commands):
        proc = subprocess.run(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        assert proc.returncode == 0, (argv, proc.stderr)
        put(f'base-readonly/{phase}-{i}.stdout', proc.stdout)
        put(f'base-readonly/{phase}-{i}.stderr', proc.stderr)
        records.append({'argv': argv, 'exit_code': proc.returncode, 'stdout': identity(proc.stdout), 'stderr': identity(proc.stderr)})
    assert (ROOT / f'base-readonly/{phase}-0.stdout').read_text().strip() == BASE_SHA
    assert (ROOT / f'base-readonly/{phase}-1.stdout').read_text().strip() == BASE_TREE
    assert (ROOT / f'base-readonly/{phase}-4.stdout').read_bytes() == b''
    index_path = subprocess.check_output(['git', '-C', checkout, 'rev-parse', '--path-format=absolute', '--git-path', 'index'], env=env).decode().strip()
    index = Path(index_path).read_bytes()
    assert identity(index)['sha256'] == base['git_index_sha256']
    put(f'base-readonly/{phase}-index.original', index)
    snapshots.append({'phase': phase, 'commands': records, 'index_path': index_path, 'index': identity(index)})

original_bindings = []
for row in classification:
    rel = row['path']
    raw = (ORIGINAL / 'producer-source' / rel).read_bytes()
    assert identity(raw)['git_blob'] == row['producer184']['sha'], rel
    assert len(raw) == row['producer184']['size'], rel
    if row['current_f9']:
        previous = (ORIGINAL / 'before' / rel).read_bytes()
        assert identity(previous)['git_blob'] == row['current_f9']['sha'] == row['producer_base']['sha'], rel
    original_bindings.append({'path': rel, 'original_path': str(ORIGINAL / 'producer-source' / rel), 'mode': row['producer184']['mode'], **identity(raw)})
write_json('producer-originals-binding.json', original_bindings)

records = []
patches = []
for rel in SELECTED:
    row = rows[rel]
    producer_bytes = (ORIGINAL / 'producer-source' / rel).read_bytes()
    final = producer_bytes
    if rel == MATERIAL_PATH:
        value = producer_bytes.decode('utf-8')
        for old, new in REPLACEMENTS:
            assert value.count(old) == 1
            value = value.replace(old, new)
        final = value.encode('utf-8')
        restored = value
        for old, new in reversed(REPLACEMENTS):
            assert restored.count(new) == 1
            restored = restored.replace(new, old)
        assert restored.encode() == producer_bytes
    before = (ORIGINAL / 'before' / rel).read_bytes() if row['current_f9'] else b''
    if row['current_f9']:
        put('before/' + rel, before)
    put('producer-source/' + rel, producer_bytes)
    put('final-source/' + rel, final)
    os.chmod(ROOT / 'final-source' / rel, 0o644)
    records.append({
        'path': rel,
        'mode': row['producer184']['mode'],
        'old_git_blob': row['current_f9']['sha'] if row['current_f9'] else None,
        'producer_git_blob': row['producer184']['sha'],
        'final': identity(final),
        'local_path': str(ROOT / 'final-source' / rel),
        'origin': 'two bounded material substitutions on exact producer' if rel == MATERIAL_PATH else 'byte-identical published producer blob',
    })
    patches.append(''.join(difflib.unified_diff(before.decode().splitlines(True), final.decode().splitlines(True),
                                              fromfile='a/' + rel if before else '/dev/null', tofile='b/' + rel)))
put('integration.patch', ''.join(patches).encode())
material_old = (ROOT / 'producer-source' / MATERIAL_PATH).read_text()
material_new = (ROOT / 'final-source' / MATERIAL_PATH).read_text()
put('material-repair.patch', ''.join(difflib.unified_diff(material_old.splitlines(True), material_new.splitlines(True),
                                                        fromfile='a/' + MATERIAL_PATH, tofile='b/' + MATERIAL_PATH)).encode())

boundaries = []
for name in ['kart_vehicle_regression.gd', 'kart_physics_regression.gd', 'kart_dynamic_coastal_foam_regression.gd']:
    rel = 'scripts/tests/' + name
    b = (ORIGINAL / 'reference-source' / rel).read_bytes()
    ident = identity(b)
    assert ident['git_blob'] == base['entries'][rel]['sha'] == head_entries[rel]['sha']
    put('protected-source/' + rel, b)
    boundaries.append({'path': rel, 'f9_and_producer_git_blob': ident['git_blob'], **ident, 'changed': False})
roster = (ORIGINAL / 'reference-source/assets/characters/rivals/roster.json').read_bytes()
assert identity(roster)['git_blob'] == '051bfb33c4aa13f3cce375c91f81c241b4b7a340'
assert base['entries']['assets/characters/rivals/roster.json']['sha'] == head_entries['assets/characters/rivals/roster.json']['sha'] == identity(roster)['git_blob']
put('protected-source/assets/characters/rivals/roster.json', roster)

dependencies = []
for rel in SELECTED:
    value = (ROOT / 'final-source' / rel).read_text()
    refs = set(re.findall(r'(?:preload|load|FileAccess\.get_file_as_string)\(\s*"res://([^"\n]+)"', value))
    if rel == 'scripts/games/lumo_opponent_roster.gd':
        refs.add('assets/characters/rivals/roster.json')
    for ref in sorted(refs):
        assert ref in SELECTED or ref in base['entries'], (rel, ref)
        if ref in SELECTED:
            binding = next(r for r in records if r['path'] == ref)
            origin = 'selected final source'
            sha = binding['final']['git_blob']
        else:
            sha = base['entries'][ref]['sha']
            origin = 'unchanged f9 source'
            assert sha == head_entries[ref]['sha'], (ref, sha)
        dependencies.append({'owner': rel, 'resource': 'res://' + ref, 'git_blob': sha, 'origin': origin})
write_json('dependency-binding.json', {
    'scope': 'all direct literal load/preload references in the ten selected sources plus roster data; runtime rig candidates remain explicit unavailable data',
    'dependencies': dependencies,
    'roster': identity(roster),
    'runtime_ready_entries': [r['id'] for r in json.loads(roster)['opponents'] if r['runtimeReady']],
    'island_source_unchanged': base['entries']['scripts/games/kart_island.gd'],
    'island_connection': 'Existing island sets reference_rival metadata before configure/add_child. Producer vehicle _ready reads that exact metadata. No island/camera/FX/ring hunk is selected.',
})

function_comparison = []
for rel in ['scripts/games/kart_vehicle.gd', 'scripts/games/lumo_opponent_roster.gd']:
    old = function_blocks((ROOT / 'before' / rel).read_text())
    new = function_blocks((ROOT / 'final-source' / rel).read_text())
    function_comparison.append({
        'path': rel,
        'unchanged': [{'name': name, **identity(value)} for name, value in old.items() if new.get(name) == value],
        'changed': [name for name, value in old.items() if name in new and new[name] != value],
        'added': [name for name in new if name not in old],
        'removed': [name for name in old if name not in new],
    })
for name in ['_mat', '_merge_static', '_vertex_material', '_paint_mesh', '_far_geometry', '_update_detail', '_set_far_detail']:
    vehicle = function_comparison[0]
    assert name in [r['name'] for r in vehicle['unchanged']], name
write_json('function-preservation.json', function_comparison)

old_overwrites = [r['path'] for r in records if r['old_git_blob']]
assert len(old_overwrites) == 3
unchanged = [{'path': path, **record} for path, record in base['entries'].items() if path not in old_overwrites]
assert len(unchanged) == 3754
write_json('source-preservation.json', {
    'kind': 'proposed tree overlay, not an executed or published tree',
    'base_head': BASE_SHA, 'base_tree': BASE_TREE,
    'base_leaves': 3757, 'proposed_leaves': 3764,
    'overwritten_paths': old_overwrites, 'new_paths': [r['path'] for r in records if not r['old_git_blob']],
    'unchanged_base_paths': unchanged,
    'protected_boundary_tests': boundaries,
    'scope': 'All unselected base paths remain exact: camera/island, routes/rings, C4/Memory/Quiz/English, PCM/host bridge, notices/export, 52/17, Dream/Discovery and every workflow.',
})

dispositions = []
for rel, row in rows.items():
    if rel in SELECTED:
        disposition = 'candidate_for_isolated_checkpoint_then_required_engine_gate'
    elif rel.startswith('.github/workflows/') or rel.startswith('docs/'):
        disposition = 'producer_reference_only_no_workflow_or_pass_transfer'
    elif rel in ['scripts/games/kart_island.gd', 'scripts/games/kart_item_symbols.gd', 'scripts/games/kart_resonance_system.gd', 'scripts/games/kart_rival_item_fx.gd'] or 'item_' in rel or 'resonance_' in rel:
        disposition = 'held_separate_ring_item_scope_one_torus_contract_conflict'
    else:
        disposition = 'held_separate_route_tunnel_roadside_scope_legacy_extent_contract_conflict'
    dispositions.append({'path': rel, 'old_git_blob': row['current_f9']['sha'] if row['current_f9'] else None,
                         'producer_git_blob': row['producer184']['sha'], 'mode': row['producer184']['mode'],
                         'disposition': disposition})
write_json('full-producer-disposition.json', dispositions)

write_json('material-analysis.json', {
    'status': 'STATIC_PRODUCT_CANDIDATE_NOT_RUNTIME_PASS',
    'evidence': 'original job 132580113281 assertion at kart_vehicle_regression.gd:255; no near_surfaces value was printed before failure',
    'unchanged_acceptance': 'optimized.surfaces < original.surfaces * 0.7 and optimized.surfaces <= 64',
    'causal_source_observation': 'kart_vehicle._merge_static groups by metallic, roughness, emission_enabled, emission_energy_multiplier, normal texture and emission colour. The new Aero helper uses one accent colour but three different emissive finish keys on six rigid meshes under the same body.',
    'before_families': [[0.35, 0.26, 0.75], [0.0, 0.26, 0.5], [0.35, 0.26, 0.65]],
    'after_family': [0.35, 0.26, 0.75],
    'static_effect': 'The three added accent-light keys collapse to one; at least two distinct new keys are removed in that body. The complete runtime surface count and ratio are not measured here.',
    'visual_change': 'Exhaust energy ring metallic 0 -> .35 and emission .5 -> .75; raised chevron emission .65 -> .75. Sill finish is unchanged. No shade/appearance equivalence is claimed.',
    'preserved': ['all geometry constructors, vertices and transforms', 'all 22 declared Aero components and datums', 'all colours', 'far-skip and near-only assignments', 'existing material quantization', 'body/cinema ownership', 'animated joints and LOD boundaries', 'all existing acceptance thresholds'],
    'replacements': [{'before': a, 'after': b} for a, b in REPLACEMENTS],
    'remaining_gate': 'An actual post-checkpoint KartVehicle run must prove both original bounds for every animal; no PASS is inferred from this reduction.',
})

runs = json.loads((ORIGINAL / 'originals/ci184-runs.original.json').read_bytes())
assert all(r['head_sha'] == PRODUCER for r in runs['workflow_runs'])
write_json('ci-observation.json', {
    'kind': 'immutable original snapshot, not a later complete-CI claim',
    'pr183_exact_head_runs': json.loads((ORIGINAL / 'originals/ci183-runs.original.json').read_bytes())['total_count'],
    'pr184_head': PRODUCER,
    'runs': [{k: r.get(k) for k in ['id', 'name', 'head_sha', 'run_attempt', 'status', 'conclusion', 'created_at', 'updated_at', 'html_url']} for r in runs['workflow_runs']],
    'snapshot_totals': dict(collections.Counter(r['conclusion'] or r['status'] for r in runs['workflow_runs'])),
    'authoritative_log_root': str(ORIGINAL / 'originals/jobs'),
    'known_failures': [
        {'job': 132580113281, 'path': 'scripts/tests/kart_vehicle_regression.gd', 'message': 'Vertex colours must meaningfully reduce near material passes', 'classification': 'real measured failure; exact count and failing conjunct not printed'},
        {'job': 132580113072, 'path': 'scripts/tests/kart_dynamic_coastal_foam_regression.gd', 'message': 'Unrelated tracks should keep their original coast geometry', 'classification': 'real failure; old <=150m range conflicts with published longer forest/city controls'},
        {'job': 132580113476, 'path': 'scripts/tests/kart_physics_regression.gd', 'message': 'A ring uses only one opaque draw surface', 'classification': 'real failure; exact one-child TorusMesh contract conflicts with new multi-mesh gate'},
    ],
    'modular_success_scope': {'run': 43638372756, 'job': 132580113054, 'marker': '[KartModularParts] PASS: 12 mobile tracks + 2 high-detail scenes; four live chassis; no racing/LOD authority changed', 'does_not_prove': ['surface budget', 'old coast bound', 'old one-torus gate', 'new Android or FPS result']},
})

for i, argv in enumerate(git_commands):
    proc = subprocess.run(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    assert proc.returncode == 0
    assert proc.stdout == (ROOT / f'base-readonly/before-{i}.stdout').read_bytes()
    assert proc.stderr == (ROOT / f'base-readonly/before-{i}.stderr').read_bytes()
    put(f'base-readonly/after-{i}.stdout', proc.stdout)
    put(f'base-readonly/after-{i}.stderr', proc.stderr)
after_index = Path(index_path).read_bytes()
assert after_index == index
put('base-readonly/after-index.original', after_index)
write_json('base-readonly/binding.json', {'before': snapshots[0], 'after_commands_and_index_byte_identical': True, 'after_index': identity(after_index), 'no_product_execution': True})

write_json('source-freeze.json', {
    'schema': 1,
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repository': 'Ullmann27/lumo-godot',
    'base_head': BASE_SHA, 'base_tree': BASE_TREE,
    'producer183_head': '670058d31e9807918e1150e85ec2fac53be627b0',
    'producer184_head': PRODUCER, 'producer184_tree': head['sha'],
    'source_count': len(records), 'unchanged_producer_sources': 9, 'own_adapted_sources': 1,
    'status': 'FROZEN_FOR_ISOLATED_CHECKPOINT_BEFORE_ENGINE_VALIDATION',
    'sources': records,
    'tests_executed': [],
    'requires_root_checkpoint_before_execution': True,
    'not_a_complete_pr183_pr184_integration': True,
})
print(json.dumps({'source_count': len(records), 'sources': records, 'freeze': identity((ROOT / 'source-freeze.json').read_bytes()),
                  'material_patch': identity((ROOT / 'material-repair.patch').read_bytes()),
                  'unchanged_function_counts': {r['path']: len(r['unchanged']) for r in function_comparison}}, indent=2))
