# Kart PR183/184: begrenzter Fahrzeugkandidat auf Native f9

## Ergebnis und Ausführungsgrenze

Dieser Pack enthält einen eingefrorenen **10-Pfad-Kandidaten**, noch keinen ausgeführten oder freigegebenen Integrationsstand. Basis ist `f9d9772bb932d7ee8702eeb5bca6d98c286f3b98`, Tree `4036a20ab80de78bcdf0d074b585be88c2946492`. Neun Enddateien sind exakt veröffentlichte Producer-Blobs; nur der neue Aerohelper erhält zwei eigene Materialersetzungen. Es gab keinen Engineimport, Testlauf, Renderer, Git-Index-/Ref-/CI-Eingriff und keine Änderung des aktiven APK-Kandidaten.

`source-freeze.json` enthält alle alten, veröffentlichten und neuen Blobs, Modi, Größen und SHA256. `integration.patch` ist der vollständige Anschluss gegen f9. `material-repair.patch` zeigt ausschließlich die zwei eigenen Änderungen gegen den Producer. Die Originalquellen, Vergleiche und sechs vollständigen CI-Logs sind unverändert im gesonderten Originalarchiv enthalten.

## Warum dieser kleine Produktpatch

Der echte Vehicle-Job `132580113281` auf PR184-Head `46bf4798d8b8411ef0855faa65180360258103dd` scheitert am unveränderten kombinierten Vertrag:

```gdscript
optimized.surfaces < original.surfaces * 0.7 and optimized.surfaces <= 64
```

Der Log druckt vor diesem Abbruch keine tatsächliche Oberflächenzahl. Welcher der beiden Teilausdrücke zuerst verletzt wird, ist damit nicht gemessen. Ein erfolgreicher Budgetnachweis wird hier ausdrücklich nicht behauptet.

Die Ursache zusätzlicher Materialgruppen ist im Quelltext konkret: Die neuen seitlichen Leuchtleisten, Abgas-Energieringe und erhabenen Chevrons verwenden denselben Akzentfarbwert, aber drei verschiedene Kombinationen aus Metallanteil, Rauheit und Emissionsenergie. Der unveränderte `_merge_static` bildet daraus drei getrennte Gruppen. Die zwei Ersetzungen vereinheitlichen ausschließlich diese sechs neuen Meshes auf den bereits von der Leuchtleiste benutzten Schlüssel `0.35 / 0.26 / 0.75`. Dadurch entfallen dort mindestens zwei separate Schlüssel.

Alle Konstruktoren, Punkte, Transformationen, Farben, 22 deklarierten Aero-Bauteile, Radanker, Nah-/Fernmarkierungen und Animationsgrenzen bleiben erhalten. Die optische Änderung ist offen ausgewiesen: Der Energiering erhält Metallanteil 0.35 statt 0 und Emission 0.75 statt 0.5; die Chevrons erhalten Emission 0.75 statt 0.65. Eine identische Schattierung wird nicht behauptet. Bestehende globale Materialquantisierung, Batchalgorithmus und der 64er-Grenzwert bleiben bytegleich.

Ob die tatsächliche Gesamtzahl und das Verhältnis danach die unveränderten Grenzen erfüllen, ist der erste notwendige Engine-Nachweis nach Roots Quellencheckpoint. Sollte die Grenze weiterhin verletzt werden, muss das neue Originalresultat zuerst gesichert werden; dieser Pack rechtfertigt keine automatische Wiederholung oder weitere Schwellenänderung.

## Eingeschlossener Umfang

Sieben Produktpfade verbinden die veröffentlichten Coachwork-/Rad-/Aero-Details, artspezifischen Rivalen und den validierenden Rivalenadapter. Drei unmittelbar zugehörige originale Producer-Regressionspfade sind dabei. Die bestehende `kart_island.gd` bleibt vollständig unverändert: Sie setzt bereits die `reference_rival`-Metadaten vor dem Einhängen des Fahrzeugs; der veröffentlichte Vehicle-`_ready` liest diese Metadaten selbst. Die neue direkte Island-Setterzeile ist dafür nicht erforderlich.

Die vorhandene Rivalenliste ist auf beiden Quellenständen derselbe Blob `051bfb33c4aa13f3cce375c91f81c241b4b7a340`. Alle fünf Einträge stehen weiterhin auf `runtimeReady: false`. Die neuen Adapter-Gegenfälle benutzen ausdrücklich Testmodelle im Speicher; das liefert keine bisher fehlenden produktiven Rivalen-GLBs.

Der ursprüngliche Fox-/Rabbit-Augentest wird als exakte Producer-Designanpassung ausgewiesen: Die feste alte Rabbit-Breite 0.119 wird durch kleinere Grenzen von 0.075 Breite, 0.095 Höhe und 0.022 Tiefe ersetzt. Fox-Assertions und Gelenkprüfungen bleiben bestehen. Diese Änderung darf nicht mit einer Lockerung der drei unten geschützten Grenztests verwechselt werden.

## Separat gehaltene neue Strecken und Ringformen

**Lange Strecken, Tunnel und modulare Straßenobjekte:** Der neue Zauberwald enthält unter anderem den Kontrollpunkt `(350.12, 12, -107.29)`, Holo City `(337.89, 32, -111.89)`. Beide neuen Definitionen speisen dieselbe reale Straßenkurve; die Terrain-/Wassergrenze folgt dieser Kurve. Der unveränderte Coastal-Test verlangt für genau Zauberwald und Holo City weiterhin höchstens 150 m in beiden Achsen. Der echte Job `132580113072` scheitert an diesem Vertrag. Eine auf 150 m gekappte, zur tatsächlichen Straße unpassende Wassergrenze wäre keine Reparatur. Der gesamte Routen-/Tunnel-/Straßenobjekt-Anschluss bleibt deshalb separat erhalten; er wird nicht in diesen Fahrzeugkandidaten übertragen.

**Neue Ring- und Itemdarstellung:** Der unveränderte Physics-Test verlangt genau einen direkten Mesh-Knoten `ResonanceHalo` mit `TorusMesh`, einer Oberfläche und begrenzter Emission. Der neue Producer-Ring besitzt eine Struktur, drei wirkliche Item-Symbole und sechs weitere animierte Spuren. Der echte Job `132580113476` scheitert an der Ein-Kind-Bedingung. Mehrere Meshes unter einem einzigen Container zu verstecken würde die behauptete Ein-Oberflächen-Grenze nicht erfüllen. Dieser Ring-/Item-Anschluss bleibt ebenfalls als vollständiges Original separat. Seine neue Pause-/Clock-/Banking-Arbeit wird nicht ohne die dazugehörige Darstellungsentscheidung in den aktiven Stand kopiert.

`full-producer-disposition.json` ordnet jeden der 48 eindeutigen Producerpfade zu. Die nicht angeschlossenen Dateien werden weder verworfen noch als integriert bezeichnet. Producer-Workflows und dokumentierte alte Ergebnisse sind reine Herkunftsbelege.

## Erhaltener Stand

Die beiden vollständigen Producervergleiche ergeben 20 bereits vorhandene Pfade mit exakt denselben Preimages wie f9 und 28 neue Pfade. Im ausgewählten Zehnersatz werden nur drei vorhandene Pfade ersetzt; sieben kommen hinzu. Alle übrigen 3.754 vorhandenen Blätter bleiben im vorgeschlagenen Overlay identisch. Das vollständige Mapping steht in `source-preservation.json`.

Unverändert bleiben insbesondere Camera/Island, sämtliche aktuellen Strecken und Ringe, C4/Memory/Quiz/English, PCM/Host-Rückkehr, Notice-Export und die bestehenden 52/17-, Dream-/Discovery- und Workflowgrenzen. 71 bestehende Vehicle-Funktionsblöcke und vier Roster-Funktionsblöcke wurden bytegleich gebunden. Die drei echten Grenztests Vehicle, Physics und Coastal sind sowohl auf f9 als auch beim Producer dieselben Blobs und liegen zusätzlich unverändert in `protected-source/`.

## Tatsächliche Producer-CI und nächste gezielte Prüfung

Der gesicherte exakte PR183-Head hat keine Actions-Runs. Der originale PR184-Snapshot enthält 14 erfolgreiche, fünf fehlgeschlagene und einen damals laufenden Workflow. Das ist keine Behauptung über einen späteren Gesamtabschluss. Der neue Modular-Job war tatsächlich erfolgreich; sein Marker betrifft zwölf mobile Welten, zwei detaillierte Welten und vier Chassis. Er prüft die drei hier belegten alten Grenzen nicht vollständig und ersetzt sie nicht.

Nach einem isolierten Quellencheckpoint ist zuerst der unveränderte `kart_vehicle_regression.gd` mit dem originalen Probe-Runner und seinem belegten 120-Sekunden-Budget sinnvoll. Sein vollständiger Erfolgsmarker lautet `[KartVehicle] Geometry/colours, shadows, animations, effects, LOD and hysteresis passed`. Danach gehören die vorhandenen Detail-/Kontaktgrenzen sowie die drei ausgewählten Rivalen-/Augen-Regressionsquellen zum eng betroffenen Umfang. Konkrete Ausführung und Budgets der zusätzlichen Aufrufe bestimmt Root am eingecheckten Stand; hier wurde kein Lauf gestartet und kein neuer allgemeiner Workflow gebaut.

Ein erfolgreicher lokaler Fahrzeuglauf wäre weiterhin kein Nachweis für die separat gehaltenen langen Strecken, neue Ringdarstellung, Android-GPU-Leistung oder 60 FPS.
