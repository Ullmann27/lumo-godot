# English camera ownership correction on Native2e023

The actual production scene loads learning_wonder_world.gd. Its landscape override runs after the base English layout and changes the camera to the garden framing. In the current original640×360 failure,7×360/(268−12−83)=14.5664739884, matching14.5664732758 recovered from the original projection matrix. Actual object heights remain45.69–46.62dp.

The proposal adds only an English-specific return after super._layout() and the existing validity guard. English keeps its own measured gallery fit; other activities retain all original wrapper code. The prior base-class correction, all thresholds, meshes, collision hulls, portrait layout, voice, return and tests remain unchanged.

The earlier helper's specific return was not traced. This pack does not invent that trace. The later camera override is established by the production route, complete original source and matching measured projection. No failing ruler PNG exists because the original guard stopped before its PNG write. Five earlier original PNGs remain in the separate complete CI archive.

No engine, renderer, test, Git mutation, workflow or device run was performed. A fresh14-profile/17-capture English renderer on the checkpointed correction remains required, including unchanged48dp and containment/interactions.

Full current English job/API/inventory originals and the original layout are included. The original4.67MB ZIP and all extracted74 entries remain separately unchanged in the run evidence pack; they are referenced, not duplicated here. The previous unsuccessful source proposal/evidence remains historical and untouched.
