set -euo pipefail
mkdir -p "$RUNNER_TEMP/kart-check/scripts/games" "$RUNNER_TEMP/kart-check/scripts/tests" "$RUNNER_TEMP/kart-check/scripts/characters/lumo"
mkdir -p "$RUNNER_TEMP/kart-check/scripts/games/visual" "$RUNNER_TEMP/kart-check/assets/shaders"
mkdir -p "$RUNNER_TEMP/kart-check/assets/characters/lumo_animated"
cp scripts/games/kart_vehicle.gd scripts/games/kart_fleet.gd scripts/games/kart_fur_geometry.gd scripts/games/kart_character_finish.gd "$RUNNER_TEMP/kart-check/scripts/games/"
cp scripts/characters/lumo/lumo_kart_animation_adapter.gd scripts/characters/lumo/lumo_rigged_actor.gd scripts/characters/lumo/lumo_walk_locomotion.gd "$RUNNER_TEMP/kart-check/scripts/characters/lumo/"
cp scripts/characters/lumo/lumo_platform_pose.gd scripts/characters/lumo/lumo_teacher_pose.gd scripts/characters/lumo/lumo_body_space_pose.gd "$RUNNER_TEMP/kart-check/scripts/characters/lumo/"
cp assets/characters/lumo_animated/lumo_studio_clips.gd "$RUNNER_TEMP/kart-check/assets/characters/lumo_animated/"
cp scripts/games/visual/kart_cinema_materials.gd "$RUNNER_TEMP/kart-check/scripts/games/visual/"
cp assets/shaders/kart_lumo_cinema_high.gdshader assets/shaders/kart_lumo_cinema_mobile.gdshader "$RUNNER_TEMP/kart-check/assets/shaders/"
cp scripts/tests/kart_vehicle_regression.gd "$RUNNER_TEMP/kart-check/scripts/tests/"
printf 'config_version=5\n\n[application]\nconfig/name="Kart vehicle regression"\n\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n' > "$RUNNER_TEMP/kart-check/project.godot"
python3 tools/run_godot_probe.py --log "$RUNNER_TEMP/import.log" --timeout 120 --required 'Godot Engine v4.6.3' -- Godot_v4.6.3-stable_linux.x86_64 --headless --path "$RUNNER_TEMP/kart-check" --editor --import --quit
python3 tools/run_godot_probe.py --log "$RUNNER_TEMP/vehicle.log" --timeout 120 --required '[KartVehicle] Geometry/colours, shadows, animations, effects, LOD and hysteresis passed' -- Godot_v4.6.3-stable_linux.x86_64 --headless --path "$RUNNER_TEMP/kart-check" --script res://scripts/tests/kart_vehicle_regression.gd
