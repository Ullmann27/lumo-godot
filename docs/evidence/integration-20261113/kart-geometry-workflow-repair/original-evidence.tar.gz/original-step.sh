set -euo pipefail
mkdir -p "$RUNNER_TEMP/kart-check/scripts/games" "$RUNNER_TEMP/kart-check/scripts/tests" "$RUNNER_TEMP/kart-check/scripts/characters/lumo"
mkdir -p "$RUNNER_TEMP/kart-check/scripts/games/visual" "$RUNNER_TEMP/kart-check/assets/shaders"
cp scripts/games/kart_vehicle.gd scripts/games/kart_fleet.gd scripts/games/kart_fur_geometry.gd scripts/games/kart_character_finish.gd "$RUNNER_TEMP/kart-check/scripts/games/"
cp scripts/characters/lumo/lumo_kart_animation_adapter.gd scripts/characters/lumo/lumo_rigged_actor.gd scripts/characters/lumo/lumo_walk_locomotion.gd "$RUNNER_TEMP/kart-check/scripts/characters/lumo/"
cp scripts/games/visual/kart_cinema_materials.gd "$RUNNER_TEMP/kart-check/scripts/games/visual/"
cp assets/shaders/kart_lumo_cinema_high.gdshader assets/shaders/kart_lumo_cinema_mobile.gdshader "$RUNNER_TEMP/kart-check/assets/shaders/"
cp scripts/tests/kart_vehicle_regression.gd "$RUNNER_TEMP/kart-check/scripts/tests/"
printf 'config_version=5\n\n[application]\nconfig/name="Kart vehicle regression"\n\n[rendering]\nrenderer/rendering_method="gl_compatibility"\n' > "$RUNNER_TEMP/kart-check/project.godot"
timeout 120s Godot_v4.6.3-stable_linux.x86_64 --headless --path "$RUNNER_TEMP/kart-check" --editor --import --quit > "$RUNNER_TEMP/import.log" 2>&1
cat "$RUNNER_TEMP/import.log"
! grep -E 'SCRIPT ERROR:|Parse Error:' "$RUNNER_TEMP/import.log"
timeout 120s Godot_v4.6.3-stable_linux.x86_64 --headless --path "$RUNNER_TEMP/kart-check" --script res://scripts/tests/kart_vehicle_regression.gd > "$RUNNER_TEMP/vehicle.log" 2>&1
cat "$RUNNER_TEMP/vehicle.log"
! grep -E 'SCRIPT ERROR:|Assertion failed|Parse Error:' "$RUNNER_TEMP/vehicle.log"
grep -F '[KartVehicle] Geometry/colours, shadows, animations, effects, LOD and hysteresis passed' "$RUNNER_TEMP/vehicle.log"
