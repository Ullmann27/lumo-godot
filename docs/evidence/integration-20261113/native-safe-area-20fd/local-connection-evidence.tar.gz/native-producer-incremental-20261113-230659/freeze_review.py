from pathlib import Path
import ast, hashlib, json

R=Path('/workspace/scratch/b3485b7bb989')
P=R/'native-producer-incremental-20261113-230659'
BEFORE=R/'native-producer-incremental-20261113-224228'
INTEGRATION=R/'native-safe-area-integration-20fd-evidence'
WORK=R/'lumo-native-safe-area-preparation-993c'
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(p,d): p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def record(p):
 b=p.read_bytes(); return {'path':p.relative_to(P).as_posix(),'bytes':len(b),'sha256':sha(b)}
new_pulls=json.loads((P/'original-api/pulls-latest15.json').read_text()); old_pulls=json.loads((BEFORE/'original-api/pulls-latest15.json').read_text())
old_by={x['number']:x for x in old_pulls}
changed_pr=[{'number':x['number'],'before':old_by[x['number']]['head']['sha'],'after':x['head']['sha']} for x in new_pulls if x['number'] in old_by and old_by[x['number']]['head']['sha']!=x['head']['sha']]
changed_refs=[]; refs=[]
for p in sorted((P/'original-api').glob('ref-*.json')):
 before=json.loads((BEFORE/'original-api'/p.name).read_text())['object']['sha']; after=json.loads(p.read_text())['object']['sha']
 row={'ref':p.stem.removeprefix('ref-'),'before':before,'after':after};refs.append(row)
 if before!=after:changed_refs.append(row)
assert len(new_pulls)==15 and len(refs)==7 and len(changed_pr)==1 and changed_pr[0]['number']==158 and len(changed_refs)==1 and changed_refs[0]['ref']=='studio'
commit=json.loads((P/'original-api/commit-803e7a62.json').read_text()); compare=json.loads((P/'original-api/compare-20fd-803e.json').read_text())
assert [x['sha'] for x in commit['parents']]==['20fd2880494c10f8f7d3a266956995e97f9011df'] and compare['total_commits']==1
files={x['filename']:x for x in commit['files']}
assert set(files)=={x['filename'] for x in compare['files']}
code=[p for p in files if not p.startswith('docs/')]; assert code==['tools/tests/test_nextgen_runner.py'] and len(files)==33
verified=[]
for p in sorted((P/'new-803e7a62').rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(P/'new-803e7a62').as_posix();data=p.read_bytes();assert blob(data)==files[rel]['sha'],rel
 verified.append(dict(record(p),git_blob=blob(data)))
new_test=P/'new-803e7a62/tools/tests/test_nextgen_runner.py'; old_test=P/'base-20fd2880/tools/tests/test_nextgen_runner.py'
assert sha(new_test.read_bytes())=='58bc8cf4ddec61355bdd349612d99360b6142a3c3969ce12366e14c91c7e7560'
assert sha(old_test.read_bytes())=='fe0426c3e895d10ecfb4b931d8883625baeac6d387f211f2d2eb700d6c33872e'
def tests(path):
 return {c.name+'.'+m.name:ast.dump(m,include_attributes=False) for c in ast.parse(path.read_text()).body if isinstance(c,ast.ClassDef) for m in c.body if isinstance(m,ast.FunctionDef) and m.name.startswith('test_')}
a,b=tests(old_test),tests(new_test); original_nextgen=[k for k in a if k.startswith('NextgenRunnerTests.')]
assert all(a[k]==b[k] for k in original_nextgen)
execution=P/'new-803e7a62/docs/evidence/studio-runner-contract-20261113/green-full-suite-execution.json'; execution_data=json.loads(execution.read_text())
log=P/'new-803e7a62/docs/evidence/studio-runner-contract-20261113/green-full-suite.log'
assert sha(log.read_bytes())==execution_data['log_sha256'] and execution_data['exit_code']==0 and 'Ran 68 tests in 13.735s' in log.read_text()
source_manifest=json.loads((INTEGRATION/'source-final-manifest.json').read_text())
assert len(source_manifest['files'])==25
for row in source_manifest['files']: assert sha((WORK/row['path']).read_bytes())==row['sha256'],row['path']
ours=json.loads((INTEGRATION/'runner-tests-results.json').read_text());assert ours['all_passed'] and ours['source_unchanged']
for row in ours['results']:assert sha((INTEGRATION/row['log']).read_bytes())==row['log_sha256']
write(P/'review.json',{
 'schema':1,'mode':'Read-only immutable published-source comparison; no source edits, refs, new tests or retries.',
 'request_started_at_utc':'2026-11-13T23:06:59Z','baseline_snapshot':str(BEFORE),'baseline_snapshot_manifest_sha256':sha((BEFORE/'manifest.json').read_bytes()),
 'observed_prs':15,'observed_refs':7,'changed_prs':changed_pr,'refs':refs,'new_commit':commit['sha'],'tree':commit['commit']['tree']['sha'],'parent':commit['parents'][0]['sha'],
 'delta':{'total_paths':33,'test_code_paths':code,'evidence_paths':32,'product_runtime_runner_workflow_paths_changed':[],'changed_test_git_blob':blob(new_test.read_bytes()),'changed_test_sha256':sha(new_test.read_bytes()),'original_before_sha256':sha(old_test.read_bytes()),'downloaded_blob_verified_files':verified},
 'test_delta':{'old_test_methods':len(a),'new_test_methods':len(b),'unchanged_original_nextgen_methods':original_nextgen,'new_negative_mutations':24,'description':'Producer-only fixture adjustment from11 to16 Studio calls and30 to37 images; new12 Cards-sidecar and12 shared-report negative mutations. Existing modes/budgets and all older images remain required.'},
 'integration_comparison':{'frozen_pack':str(INTEGRATION),'handoff_sha256':sha((INTEGRATION/'handoff.json').read_bytes()),'all_25_final_files_unchanged':True,'actual_prior_tests':'4 Safe-Area helper methods plus20 Runner/workflow/raster methods passed before this review; not rerun here.','call_contract':'Our exact16 Studio and48 Nextgen pairs already include all five added modes and the same budgets.','raster_contract':'Our renderer-images remains24 Studio; separate Puzzle6 and Safe-Area7 manifests preserve the full37 equivalent roster. Nextgen also retainsVillage4 andTouch6/32.','why_not_replace_file':'The producer test extracts an inline Python block from its Studio runner. Our integrated runner calls existing strict shared helpers and also contains full Nextgen/workflow contract coverage. The producer positive Cards fixture omits layout_sequence, paused and discard.id, and its Mobile fixture omits checks/physical dimensions; those inputs are intentionally insufficient for our stronger original-sidecar/report contract.','negative_coverage':'Our existing targeted cases cover missing all seven PNGs, altered PNG identity/dimensions, schema boolean, integer sequence, pending/unsettled/hidden/source/viewport/phase, empty hand/discard/IDs, nonfinite JSON, failed Cards report, false device/renderer claim, unsafe/missing/small Mobile targets and changed roster/hash. Producer also isolates malformed JSON, schema2 and missing Mobile report/roster variants; source inspection shows these are already rejected by the current parser, but no new execution of those exact variants is claimed.'},
 'producer_validation_read':{'reported_source':'20fd2880494c10f8f7d3a266956995e97f9011df plus only the now-published test change','red_tests':6,'red_failures':2,'green_full_tools_tests':68,'green_failures':0,'green_skips':0,'green_log_sha256':sha(log.read_bytes()),'runtime_proof':False,'source_and_log_hashes_verified':True},
 'preserved_rejected_ci':{'producer_run':43520242403,'head':'20fd2880494c10f8f7d3a266956995e97f9011df','conclusion':'failure','failed_job':132218856095,'failed_step':'Verify fail-closed collection of every independent module','cause':'Old orchestration fixtures rejected five additional calls and lacked three Cards PNGs.','independent_studio_job':'16 gates and37 raster originals succeeded at20fd; not a combined-source or Android result.','bundle':'skipped','archive':'skipped','no_old_evidence_relabelled':True},
 'recommendation':'No additional product, runner or workflow connection is missing from the25-path frozen integration. Keep the stricter current integrated tests/helper; retain this producer test-only correction and failed20fd provenance separately. Fresh combined rendering and actual Android acceptance remain mandatory.'
})
(P/'README.md').write_text('''# Incremental Native source review:20fd →803e

The original23:06:59 UTC bounded query covers seven known producer refs and the latest15 Native PRs. Only Studio/PR158 changed:20fd2880 →803e7a62, one direct child commit. The six other refs and14 other PR heads are unchanged; PR160 remains993c.

The complete commit/compare responses show33 changed paths: exactly one test source (`tools/tests/test_nextgen_runner.py`) and32 documentation/evidence files. There is no additional product, runtime, runner or workflow correction. The ten downloaded new-source/evidence files are verified against their published Git blob identities. The original prior test is preserved separately.

The producer repair updates old synthetic fixtures from11 to16 Studio invocations and30 to37 images and adds24 isolated rejection cases. Its original six-test run had two failures. The published corrected full tools/tests log has68 tests,0 failures,0 skips; the log and changed test hashes match its source binding. These are test-orchestration results, not renderer/Android claims.

Our separately frozen25-path integration already has16 Studio/48 Nextgen calls and the stricter split24 Studio +6 Puzzle +7 Safe-Area raster contract, retainingVillage4 andTouch6/32. Its four Safe-Area helper and20 Runner/workflow tests had already passed. All25 final source hashes remained unchanged during this read-only review. The producer fixture file targets its inline raster block and cannot replace the integrated shared-helper tests. No further local test run or source adoption was performed.

The producer20fd workflow43520242403 remains an explicitly rejected total run: new-worlds job132218856095 failed the two historical fixture tests; bundle and archive skipped. Its independent16-gate/37-image Studio success is a partial20fd result only. New combined-source rendering and later Android verification remain required.

`review.json` records exact scopes, source hashes, read-only negative-case comparison and why no new runtime connection is missing. Raw API responses and downloaded published files retain their original bytes.
''')
rows=[record(p) for p in sorted(P.rglob('*')) if p.is_file() and p.relative_to(P).as_posix() not in ('manifest.json','SHA256SUMS')]
write(P/'manifest.json',{'schema':1,'state':'frozen','source':commit['sha'],'parent':commit['parents'][0]['sha'],'scope':'Read-only producer delta with exact raw source/evidence; no fresh runtime acceptance','files':rows})
all_rows=rows+[record(P/'manifest.json')]
(P/'SHA256SUMS').write_text(''.join(x['sha256']+'  '+x['path']+'\n' for x in sorted(all_rows,key=lambda x:x['path'])))
for row in all_rows:assert sha((P/row['path']).read_bytes())==row['sha256']
print(json.dumps({'state':'frozen','review':str(P/'review.json'),'review_sha256':sha((P/'review.json').read_bytes()),'manifest_sha256':sha((P/'manifest.json').read_bytes()),'checksums_sha256':sha((P/'SHA256SUMS').read_bytes()),'files':len(rows),'test_git_blob':blob(new_test.read_bytes()),'unchanged_integration_paths':25},indent=2))
