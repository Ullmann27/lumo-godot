from pathlib import Path
import datetime, hashlib, json, shutil, subprocess

ROOT = Path('/workspace/scratch/b3485b7bb989')
WORK = ROOT / 'lumo-native-safe-area-preparation-993c'
OUT = ROOT / 'native-safe-area-integration-20fd-evidence'
SOURCE = ROOT / 'native-producer-incremental-20261113-224228'
HEAD = '3497fc3cf9c3100ceb05f86c834f1668422d2dd8'
TREE = 'f13dd5fc5540ecb7705c5f18bf3cf8ba6e79d7a6'
PUBLISHED = '993c145304c3e5f8aa947e1c7a949a8ef8685415'
PRODUCER = '20fd2880494c10f8f7d3a266956995e97f9011df'
BASE = '796b2818ff729dc5389a92f8bf1f7fd7e6b6d93e'

def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
def write(path, value): path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def git(*args): return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=WORK)
def entry(root, path):
    data = path.read_bytes()
    return {'path': path.relative_to(root).as_posix(), 'bytes': len(data), 'sha256': sha(data)}
def index(root):
    return [entry(root, p) for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink() and p.relative_to(root).as_posix() not in ('manifest.json', 'SHA256SUMS')]
def freeze_manifest(root, value):
    value['files'] = index(root)
    write(root/'manifest.json', value)
    rows = value['files'] + [entry(root, root/'manifest.json')]
    (root/'SHA256SUMS').write_text(''.join(r['sha256'] + '  ' + r['path'] + '\n' for r in sorted(rows, key=lambda r:r['path'])))
    for row in rows:
        p=root/row['path']; assert p.stat().st_size==row['bytes'] and sha(p.read_bytes())==row['sha256'], row['path']
    return {'manifest_sha256':sha((root/'manifest.json').read_bytes()), 'checksums_sha256':sha((root/'SHA256SUMS').read_bytes()), 'files':len(value['files'])}

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
assert not git('diff','--cached','--name-only').strip()
review=json.loads((SOURCE/'selective-merge-review.json').read_text())
paths=[r['path'] for r in review['rows']]+['tools/validate_nextgen.sh','tools/verify_safe_area_rasters.py','tools/tests/test_safe_area_rasters.py','tools/tests/test_nextgen_runner.py']
paths=sorted(set(paths)); assert len(paths)==25
changed=git('diff','--name-only').decode().splitlines(); assert set(changed)<=set(paths), changed
assert subprocess.run(['git','--no-optional-locks','diff','--check','--',*paths],cwd=WORK,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode==0

producer_tree=json.loads((SOURCE/'original-api/tree-20fd2880.json').read_text())
base_tree=json.loads((SOURCE/'original-api/tree-796b2818.json').read_text())
assert not producer_tree['truncated'] and not base_tree['truncated']
pt={r['path']:r for r in producer_tree['tree'] if r['type']=='blob'}
bt={r['path']:r for r in base_tree['tree'] if r['type']=='blob'}
delta=[p for p in sorted(set(pt)|set(bt)) if pt.get(p,{}).get('sha')!=bt.get(p,{}).get('sha')]
assert len(delta)==45 and len(review['rows'])==21
for p in delta:
    data=(SOURCE/'new-20fd2880'/p).read_bytes()
    assert blob(data)==pt[p]['sha'] and len(data)==pt[p]['size'], p
write(SOURCE/'source-delta.json', {'schema':1,'producer':PRODUCER,'parent':BASE,'producer_tree':producer_tree['sha'],'parent_tree':base_tree['sha'],'changed_paths':45,'source_runner_paths':21,'published_evidence_paths':24,'all_published_blobs_verified':True,'rows':[{'path':p,'old_blob':bt.get(p,{}).get('sha'),'published_blob':pt[p]['sha'],'bytes':pt[p]['size'],'sha256':sha((SOURCE/'new-20fd2880'/p).read_bytes())} for p in delta]})
refs={p.stem.removeprefix('ref-'):json.loads(p.read_text())['object']['sha'] for p in (SOURCE/'original-api').glob('ref-*.json')}
write(SOURCE/'handoff.json',{'schema':1,'observed_at_utc':'2026-11-13T22:42:28Z','scope':'One incremental published-source check: latest 15 Native pull-request heads and seven known producer refs. No tests, source edits or ref mutations in producer trees.','new_source':PRODUCER,'parent':BASE,'source_tree':producer_tree['sha'],'refs':refs,'new_published_ref':'studio','unchanged_other_refs':6,'source_delta':'source-delta.json','all_45_source_and_evidence_objects_verified_against_git_tree':True,'integration_review':'selective-merge-review.json','known_limits':['Published evidence is a source checkpoint, not completed Cards-renderer or actual Android acceptance.','Merge candidates retain the original three-way conflict state; repaired final sources and actual local Red/Green live in the separate integration pack.']})
(SOURCE/'README.md').write_text('# Published Native increment — 20fd2880\n\nThe 22:42:28 UTC snapshot binds PR 158 and the Studio ref to `20fd2880494c10f8f7d3a266956995e97f9011df`, whose parent is `796b2818ff729dc5389a92f8bf1f7fd7e6b6d93e`. The other six known producer refs and fourteen other queried pull-request heads did not change in this bounded comparison. PR 160 remains `993c145304c3e5f8aa947e1c7a949a8ef8685415`.\n\nThe original API commit response did not enumerate changed files. Both complete, untruncated Git trees establish 45 changed blobs: 21 source/runner paths and 24 published evidence files. Every downloaded new file was checked against its Git blob ID and byte size. Raw API responses, exact before/after source bytes and the initial three-way candidates are retained.\n\nThe initial candidate in `tools/validate_studio.sh` contains the preserved textual merge conflict for review; it is not the final source. The final integration and its actual Cards double-inset Red/Green proof are in the sibling `native-safe-area-integration-20fd-evidence` pack. No published renderer completion or Android result is inferred from source delivery.\n')
sourcepack=freeze_manifest(SOURCE,{'schema':1,'scope':'Immutable published-source snapshots and original initial merge review, not a runtime acceptance','producer':PRODUCER,'producer_tree':producer_tree['sha'],'parent':BASE,'integration_base':PUBLISHED})

rows=[]; copies=OUT/'source-final'
for p in paths:
    data=(WORK/p).read_bytes(); assert b'<<<<<<<' not in data and b'>>>>>>>' not in data, p
    q=copies/p; q.parent.mkdir(parents=True,exist_ok=True); q.write_bytes(data)
    old=subprocess.run(['git','--no-optional-locks','show',HEAD+':'+p],cwd=WORK,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    rows.append({'path':p,'bytes':len(data),'git_blob':blob(data),'sha256':sha(data),'base_blob':blob(old.stdout) if old.returncode==0 else None,'published_producer_blob':pt.get(p,{}).get('sha'),'matches_published_producer':pt.get(p,{}).get('sha')==blob(data),'snapshot':'source-final/'+p})
write(OUT/'source-final-manifest.json',{'schema':1,'worktree':str(WORK),'local_base_commit':HEAD,'published_base_commit':PUBLISHED,'base_tree':TREE,'producer_commit':PRODUCER,'files':rows,'count':len(rows),'no_index_or_ref_changes':True,'excluded':'Generated import cache symlink and generated .uid files are not deliverables.'})
(OUT/'source-paths.txt').write_text(''.join(p+'\n' for p in paths))
patch=git('diff','--binary','--',*paths)
for row in rows:
    if row['base_blob'] is None:
        result=subprocess.run(['git','--no-optional-locks','diff','--no-index','--binary','--','/dev/null',row['path']],cwd=WORK,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert result.returncode==1, row['path']
        patch+=result.stdout
(OUT/'integration.patch').write_bytes(patch)

runtime=json.loads((OUT/'focused-before-manifest.json').read_text())
for row in runtime['files']:
    assert sha((WORK/row['path']).read_bytes())==row['sha256'], row['path']
assert len(runtime['files'])==1231
runner=json.loads((OUT/'runner-tests-before.json').read_text())
# This existing wrapper manifest is itself retained unchanged. Independently
# bind the exact nine tool files at the final freeze.
tool_names=['tools/validate_nextgen.sh','tools/validate_studio.sh','tools/verify_safe_area_rasters.py','tools/tests/test_safe_area_rasters.py','tools/tests/test_nextgen_runner.py','tools/verify_studio_rasters.py','tools/verify_village_rasters.py','tools/verify_puzzle_menu_rasters.py','tools/run_godot_probe.py']
write(OUT/'freeze-verification.json',{'schema':1,'runtime_manifest':'focused-before-manifest.json','runtime_files_checked':1231,'runtime_unchanged_at_final_freeze':True,'final_tool_files':[dict(entry(WORK,WORK/p),git_blob=blob((WORK/p).read_bytes())) for p in tool_names],'source_paths':25,'tracked_changes':len(changed),'new_source_paths':sum(r['base_blob'] is None for r in rows),'index_empty':True,'local_head_unchanged':HEAD,'all_original_logs_preserved':True})
results=json.loads((OUT/'focused-results.json').read_text()); tests=json.loads((OUT/'runner-tests-results.json').read_text())
assert results['all_strict_passed'] and tests['all_passed'] and tests['source_unchanged']
for row in results['results']:
    assert sha((OUT/row['raw_log']).read_bytes())==row['log_sha256']
for row in tests['results']:
    assert sha((OUT/row['log']).read_bytes())==row['log_sha256']

contract=json.loads((OUT/'runner-source-contract.json').read_text())
write(OUT/'handoff.json',{'schema':1,'state':'frozen','worktree':str(WORK),'published_base':PUBLISHED,'local_base':HEAD,'base_tree':TREE,'producer':PRODUCER,'producer_parent':BASE,'producer_source_snapshot':str(SOURCE),'producer_snapshot_manifest_sha256':sourcepack['manifest_sha256'],'source_manifest':'source-final-manifest.json','source_manifest_sha256':sha((OUT/'source-final-manifest.json').read_bytes()),'source_paths':'source-paths.txt','source_count':25,'patch':'integration.patch','patch_sha256':sha(patch),'actual_conflict_repair':{'textual':'Studio runner retains existing strict Studio/Puzzle raster helpers and adds Safe-Area helper; no weakened Producer inline replacement.','semantic':'Legacy Cards header applied observed insets after the new outer UI already did so. Actual strict scene regression failed at the first single-inset assertion; the header now subtracts insets already covered by its parent before applying remaining inset plus original density margin.','red_result':'cards-safe-area-red-result.json','red_log':'cards-safe-area-red.log','red_exit_code':1,'green_result':'focused-results.json','new_regression_checks_added':20},'actual_headless_results':{'cards_safe_area_regression':682,'cards_safe_area_android_contract':20,'mobile_safe_area_regression':112,'cards_table_regression_unchanged':295},'runtime_unchanged_source_count':1231,'python_contract_tests':{'safe_area_rasters':4,'nextgen_runner_workflow_and_existing_rosters':20,'results':'runner-tests-results.json','all_passed':True},'fresh_import':{'result':'fresh-import-result.json','log':'fresh-import.log','errors':0},'runner_contract':{'previous_nextgen_pairs':43,'current_nextgen_pairs':48,'previous_studio_pairs':11,'current_studio_pairs':16,'old_pairs_preserved_in_order':True,'original_studio_pngs':24,'original_village_pngs':4,'original_puzzle_menu_pngs':6,'original_touch_pairs':6,'original_touch_pngs':32,'new_safe_area_pngs':7,'new_cards_layout_sidecars':3,'new_reports':2,'canonical_manifest':'safe-area-images.json','source_contract':'runner-source-contract.json'},'report_number_contract':{'primary_layout_sidecars':'Strict original JSON integers; not parsed and rewritten by the capture.','secondary_projected_views':'Godot JSON roundtrip makes integral schema/layout_sequence/pending fields floats. Report a3815c6d28d834a804bbce5f9d72c201daddd2b938ac8fd7461764d5a2ea660d preserves the actual five views. Root scoped the Host secondary-report parser to finite integral numbers, excluding booleans and fractions.','host_parser_changed_by':'Root; no Host files changed by this agent.'},'not_proven':['No local rendered Safe-Area capture: this environment has no DISPLAY/Xvfb.','No actual Android WindowInsets/JNI or current API37 device result; Android boundary tests use the published fixture.','No new combined Native CI run or visual approval; fresh 48-pair/7-raster CI and actual picture review are required.'],'scope_unchanged':['PR160 and the current Host848 Native993c pin were not modified.','No Git index, commit, branch/ref, receipt or Producer-worktree changes.','Generated import cache symlink and generated .uid files must not be staged.']})
(OUT/'README.md').write_text('''# Safe-Area integration of published 20fd2880 onto current Native993c

The 25 explicitly listed deliverable paths are frozen in `source-paths.txt` and `source-final-manifest.json`. `source-final/` preserves their exact bytes; `integration.patch` contains the complete tracked and newly added changes. The local parent is 3497fc3c, with the exact published993c tree f13dd5fc. The Producer source is 20fd2880 on parent796b2818. No Git index, commit, ref, pin, receipt or Producer worktree was changed.

## Actual integration repairs

The six divergent existing paths were merged against their real796b base. Later Village, Loop, Puzzle and Geometry work stays present. The Studio runner textual conflict was resolved by retaining the existing strict Studio/Puzzle helpers and adding the shared Safe-Area helper.

A clean textual Cards merge still had a concrete behavioral conflict: the previous header inset adjustment ran inside the newly inset outer UI. The real strict headless Cards scene failed the new single-application assertion, with exit1 and no PASS. The header adjustment now removes inset already covered by its parent, retaining the original density margins and legacy API. The new test adds20 checks across five published profiles and retains all previous assertions. The old Cards regression is byte-unmodified and still passes295 checks.

## Completed checks

- Fresh Godot4.6.3 headless editor import: exit0, zero ERROR/Parse/Script-error matches in the complete138413-byte raw log.
- Actual strict headless Cards safe-area682, Android boundary fixture20, shared safe-area112, old Cards295: all pass.
- All1231 source/scene/asset/runner files bound before those real probes remain byte-identical after them and at this freeze.
- Four Safe-Area raster-helper test methods and20 existing/extended Runner, workflow and raster-contract methods pass; source-bound nine-tool snapshot unchanged. Their rasters are explicitly synthetic test inputs, not visual evidence.

The active Nextgen runner retains all43 previous pairs in order and adds three headless plus two rendered pairs, totaling48. It retains the24 Studio, four Village, six Puzzle-menu and six Touch/32PNG requirements. The Studio standalone runner preserves its original11 pairs and adds the same five, totaling16. Both require the new seven-PNG, three-layout, two-report `safe-area-images.json` contract. Missing/invalid images, unsettled layouts and an ERROR after a PASS marker remain fatal.

## Exact evidence limits and next acceptance

There is no local renderer or actual Android claim. New Cards captures require1080x2400 playing/paused and2400x1080 landscape; four shared captures use2400x1080. Original primary `.layout.json` files require JSON integers. The secondary projected views in the actual headless report are separately parsed/reserialized by Godot and contain integral JSON floats; that does not alter the primary contract. Root received the exact original report and has scoped the Host parser accordingly.

A fresh combined Native CI run with all48 pairs, seven actual Safe-Area PNGs and original sidecars, followed by actual image review and later Android acceptance, remains required. Existing PR160/993c and Host848 are unchanged. Generated import cache/UID files are not deliverables and must not be staged.
''')
pack=freeze_manifest(OUT,{'schema':1,'state':'frozen','scope':'Exact25-path Native integration and source-bound focused Red/Green evidence; no rendered or Android acceptance','published_base':PUBLISHED,'base_tree':TREE,'producer':PRODUCER,'source_count':25,'handoff':'handoff.json','original_raw_bytes_preserved':True})
# The final checks are hash validation of the deliverable, not new test runs.
for row in rows:
    assert sha((WORK/row['path']).read_bytes())==row['sha256']
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('diff','--cached','--name-only').strip()
print(json.dumps({'state':'frozen','evidence':str(OUT),'handoff_sha256':sha((OUT/'handoff.json').read_bytes()),'source_manifest_sha256':sha((OUT/'source-final-manifest.json').read_bytes()),'patch_sha256':sha(patch),'source_paths':paths,'producer_pack':sourcepack,'integration_pack':pack},indent=2))
