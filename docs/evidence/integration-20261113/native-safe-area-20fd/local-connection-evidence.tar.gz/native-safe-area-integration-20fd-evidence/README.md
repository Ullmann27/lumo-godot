# Safe-Area integration of published 20fd2880 onto current Native993c

The 25 explicitly listed deliverable paths are frozen in `source-paths.txt` and `source-final-manifest.json`. `source-final/` preserves their exact bytes; `integration.patch` contains the complete tracked and newly added changes. The local parent is 3497fc3c, with the exact published993c tree f13dd5fc. The Producer source is 20fd2880 on parent796b2818. No Git index, commit, ref, pin, receipt or Producer worktree was changed.

## Actual integration repairs

The six divergent existing paths were merged against their real796b base. Later Village, Loop, Puzzle and Geometry work stays present. The Studio runner textual conflict was resolved by retaining the existing strict Studio/Puzzle helpers and adding the shared Safe-Area helper.

A clean textual Cards merge still had a concrete behavioral conflict: the previous header inset adjustment ran inside the newly inset outer UI. The real strict headless Cards scene failed the new single-application assertion, with exit1 and no PASS. The header adjustment now removes inset already covered by its parent, retaining the original density margins and legacy API. The new test adds20 checks across five published profiles and retains all previous assertions. The old Cards regression is byte-unmodified and still passes295 checks.

## Completed checks

- Fresh Godot4.6.3 headless editor import: exit0, zero ERROR/Parse/Script-error matches in the complete138413-byte raw log.
- Actual strict headless Cards safe-area682, Android boundary fixture20, shared safe-area112, old Cards295: all pass.
- All1231 source/scene/asset/runner files bound before those real probes remain byte-identical after them and at this freeze.
- Four Safe-Area raster-helper test methods and20 existing/extended Runner, workflow and raster-contract methods pass; source-bound nine-tool snapshot unchanged. Their rasters are explicitly synthetic test inputs, not visual evidence.

The active Nextgen runner retains all43 previous pairs in order and adds three headless plus two rendered pairs, totaling48. It retains the24 Studio, four Village, six Puzzle-menu and six Touch/32PNG requirements. The Studio standalone runner preserves its original11 pairs and adds the same five, totaling16. Both require the new seven-PNG, three-layout, two-report `safe-area-images.json` contract. Missing/invalid images, unsettled layouts and an ERROR after a PASS marker remain fatal.

## Exact evidence limits and next acceptance

There is no local renderer or actual Android claim. New Cards captures require1080x2400 playing/paused and2400x1080 landscape; four shared captures use2400x1080. Original primary `.layout.json` files require JSON integers. The secondary projected views in the actual headless report are separately parsed/reserialized by Godot and contain integral JSON floats; that does not alter the primary contract. Root received the exact original report and has scoped the Host parser accordingly.

A fresh combined Native CI run with all48 pairs, seven actual Safe-Area PNGs and original sidecars, followed by actual image review and later Android acceptance, remains required. Existing PR160/993c and Host848 are unchanged. Generated import cache/UID files are not deliverables and must not be staged.
