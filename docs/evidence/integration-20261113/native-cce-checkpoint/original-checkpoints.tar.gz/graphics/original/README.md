# PR160: Grafiknachweis für ccebbe24

Der Grafiklauf 43474541178 wurde am 13.11.2026 um 17:51:13 UTC mit SUCCESS
abgeschlossen. Alle drei Jobs sind erfolgreich. Die vollständigen unveränderten
API-Metadaten und Originalstempel binden ausschließlich Head
ccebbe24b489ba7971c605a2bc5187fcfea26f9e und Tree
8409dc27958dc102d7fc84b413f28642782668aa.

## Aktuelle Originalarchive und Pflichtprüfungen

| Bereich | Originalartefakt | Aktuelle PNG | Baseline-PNG | Vollständige geprüfte Logs |
|---|---:|---:|---:|---:|
| Home | 14063372285 | 24 | 20 | 19 |
| Worlds | 14062630956 | 6 | 6 | 15 |
| Feedback | 14062441473 | 6 | 0 | 6 |

Alle drei ZIPs wurden aus diesem Lauf neu geladen. Original-REST-Digests,
Größen, CRC, sichere reguläre Archivpfade und alle Bildmanifest-Einträge
wurden geprüft. Pillow 13.0.0 hat jedes der 62 PNG mit Image.verify() und
vollständigem Image.load() dekodiert. Alle 40 Artefaktlogs sind frei von den
geprüften Engine-, Script-, Parse-, Ressourcen- und Leakfehlern. Sämtliche
ursprünglichen Projektvalidator-Warnungen bleiben erhalten.

Aktuelle und historische Imports sowie alle vorgeschriebenen Gates sind
erfolgreich. Die frisch ausgeführte Baseline ist
ada5ed81ad62339f15289da62670c0a4f9f7f2b9, Tree
2e93cc5587b477ceee2d159c8aa981ff5188171b. Der Baseline-Aufnahmeharness ist
jeweils über seine Original-Hashdatei an die frisch geladenen unveränderlichen
Dateien dieses aktuellen Commits gebunden.

## Veröffentlichter Loop-Anschluss

Die tatsächliche aktuelle Grafikmatrix führt die Feedbackprobe mit X11/OpenGL
aus und meldet PASS 75 checks. Die vier veröffentlichten Loop-Assertions sind
im exakt gebundenen Probe-Blob enthalten; die drei echten Audio-Playbacks sind
vor dem Erfolgssignal freigegeben. Frische Immutable-Quellen und Original-
regression.log sind in loop-integration-current-run.json verbunden.

Der frühere lokale LOGIC_PASS 56 ist kein Ergebnis dieses Grafikjobs und wird
nicht wiederverwendet. Die separate aktuelle Nextgen-Headless-Abnahme bleibt
beim dafür zuständigen Agenten.

## Fünf tatsächlich gesichtete aktuelle Originale

required-current-image-paths.json enthält Home 1280×720 und 412×915,
Winter/Crystal Landmark 02 und Feedback Drift 03 mit vollständiger Run-,
Head-, Tree-, Archiv-, Artefakt- und PNG-Bindung.

Root hat alle fünf frischen Originaldateien direkt geöffnet. Sein unveränderter
vollständiger Beleg ist root-current-five-viewed.json, SHA256
b76976cbdf34d19da3a5631cddfcb9c90bf66b73ff3aa707a05b16bb9901591a.
Der frühere Dreierbeleg bleibt als damalige Teilsichtung ebenfalls unverändert.
Auch bei bytegleichen PNG stammt die aktuelle Bindung aus dem neuen cce-ZIP.
Es wurde kein Receipt erzeugt.

## Vollständige Proofs und Grenzen

proofs/run.json, jobs.json und artifacts.json sind die endgültigen unveränderten
GitHub-REST-Antworten. Die einzelnen Artefaktobjekte sind vollständige
Objekt-Byteausschnitte ihrer Originalsammlung; Quellen, Bytepositionen und
Hashes stehen in artifact-metadata-provenance.json. Alle Objektinhalte stimmen
mit der endgültigen Originalsammlung überein. Die drei vollständigen Joblogs
sind als unveränderte, vom Connector dekodierte UTF-8-Ausgaben gespeichert;
die Logbytes innerhalb der ZIPs sind ebenfalls vollständig erhalten.

Die bestehenden Recorder-Eingabeleser haben nur Archive, Pflichtdateien und
Proofs geprüft; kein Recorder-/Pin-/Receipt-Schreibpfad wurde aufgerufen.
Der Eingabename artifact.json bezeichnet dort das separat beigegebene originale
REST-Artefaktobjekt und keinen ZIP-Eintrag.

Dieser Nachweis gilt ausschließlich für den cce-Grafiklauf. Separate Nextgen-
und Androidjobs sowie die folgende Puzzle-Integration werden dadurch nicht
abgenommen. X11/Mesa-Aufnahmen und einzelne Bildsichtungen belegen keine
physische Android-Abnahme und keine gemessene 60-FPS-Leistung.

SHA256SUMS bindet Originalarchive, API-Proofs, Job- und Artefaktlogs,
Quellstempel, immutable Quellen, sämtliche manifestierten PNG, Captureberichte,
Root-Beobachtungen und diese Übergabedateien. Kein Rerun und keine Quellen-,
Ref-, Pin- oder Receipt-Änderung erfolgte im Rahmen dieses Auftrags.
