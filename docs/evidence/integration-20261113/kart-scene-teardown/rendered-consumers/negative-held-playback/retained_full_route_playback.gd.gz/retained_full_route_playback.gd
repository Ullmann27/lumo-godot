extends "res://scripts/tests/kart_player_full_route_regression.gd"
## Negative fixture: keep one real final playback alive across consumer teardown.
var held_playback: AudioStreamPlayback


func _capture(name: String) -> void:
	await super._capture(name)
	if name != "finish":
		return
	for player: Node in game.find_children("*", "AudioStreamPlayer", true, false):
		if not player.has_stream_playback():
			continue
		var playback = player.get_stream_playback()
		if playback.get_class() == "AudioStreamPlaybackOggVorbis":
			held_playback = playback
			print("[RetainedPlaybackFixture] held=AudioStreamPlaybackOggVorbis at actual finish")
			break
	assert(held_playback != null, "The negative fixture must hold a real final Ogg playback")
