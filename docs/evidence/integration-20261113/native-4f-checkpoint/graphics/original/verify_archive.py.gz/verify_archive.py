#!/usr/bin/env python3
"""Verify original graphics bytes and gates without creating any review receipt."""
import argparse
from io import BytesIO
import PIL
from PIL import Image
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import struct
import zipfile

HEAD = '4f3449253fd59023a2544432a178eb9efcafe4f9'
TREE = '189b7a66c731067559469e2503e3a190b337031d'
RUN = 43466005184
BASELINE = 'ada5ed81ad62339f15289da62670c0a4f9f7f2b9'
BASELINE_TREE = '2e93cc5587b477ceee2d159c8aa981ff5188171b'
REQUIRED = {
    'home': {'regression.log': '[KartHomeExperience] PASS', 'preview-resolution.log': '[KartPreviewResolution] PASS', 'cards-header.log': 'CARDS_TABLE_RUNTIME_PASS', 'home-promenade.log': '[KartHomePromenade] PASS', 'preserved-spatial-menu.log': '[SpatialMenu] PASS', 'preserved-garage.log': '[NextGenGarage] PASS', 'render.log': '[KartHomeExperienceCapture] PASS'},
    'worlds': {'regression.log': '[KartWorldExpansion] PASS', 'winter-visibility.log': '[KartWinterVisibility] PASS', 'render-winter_sprint.log': '[KartWorldExpansionCapture] PASS', 'render-crystal_canyon.log': '[KartWorldExpansionCapture] PASS'},
    'feedback': {'regression.log': '[KartDriveFeedback] PASS', 'render.log': '[KartDriveFeedbackCapture] PASS'},
}
BAD = re.compile(r'SCRIPT ERROR|Parse Error|ERROR:|\bFAIL(?:ED)?\b|ObjectDB instances leaked|still in use at exit|Unreferenced static string|handle_crash|Program crashed')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('area', choices=list(REQUIRED))
    p.add_argument('archive', type=Path)
    p.add_argument('metadata', type=Path)
    args = p.parse_args()
    root = Path(__file__).resolve().parent
    artifact = json.loads(args.metadata.read_text())
    digest = hashlib.sha256(args.archive.read_bytes()).hexdigest()
    assert artifact['name'] == 'lumo-kart-experience-' + args.area
    assert artifact['digest'] == 'sha256:' + digest
    assert artifact['expired'] is False
    assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD
    checks = []
    errors = []
    images = []
    log_results = {}
    reports = {}
    extraction = root / args.area
    extraction.mkdir(exist_ok=True)
    with zipfile.ZipFile(args.archive) as z:
        names = set()
        for item in z.infolist():
            name = item.filename.rstrip('/')
            path = PurePosixPath(name)
            assert name and not path.is_absolute() and '..' not in path.parts and '\\' not in name
            assert name not in names
            names.add(name)
            mode = stat.S_IFMT(item.external_attr >> 16)
            assert mode in (0, stat.S_IFDIR if item.is_dir() else stat.S_IFREG)
            assert not item.flag_bits & 1
        assert z.testzip() is None
        checks.append('Original archive digest, CRC and regular safe member paths verified')
        for item in z.infolist():
            target = extraction / item.filename
            if item.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                data = z.read(item)
                if target.exists():
                    assert target.read_bytes() == data, 'Different previous extraction bytes: ' + str(target)
                else:
                    target.write_bytes(data)

        def content(name):
            return z.read(name).decode('utf-8')

        assert content('source-sha.txt').strip() == HEAD
        assert content('source-tree.txt').strip() == TREE
        assert not z.read('source-dirty.txt').strip()
        assert content('engine.txt').strip() == '4.6.3.stable.official.7d41c59c4'
        checks.append('Expected current HEAD, tree, clean tracked source and exact engine family verified')
        manifest = json.loads(content('image-manifest.json'))
        seen = set()
        for image in manifest:
            name = image['file']
            assert name not in seen and name.endswith('.png') and name in names
            seen.add(name)
            data = z.read(name)
            assert len(data) == image['bytes'] and hashlib.sha256(data).hexdigest() == image['sha256']
            assert data[:8] == b'\x89PNG\r\n\x1a\n' and data[12:16] == b'IHDR'
            width, height = struct.unpack('>II', data[16:24])
            assert width > 0 and height > 0
            with Image.open(BytesIO(data)) as decoded:
                assert decoded.format == 'PNG' and not getattr(decoded, 'is_animated', False)
                assert decoded.size == (width, height)
                decoded.verify()
            with Image.open(BytesIO(data)) as decoded:
                decoded.load()
                assert decoded.size == (width, height)
            images.append(dict(image, width=width, height=height, current=name.startswith('images/')))
        assert seen == {name for name in names if name.endswith('.png')}
        checks.append('All original PNG bytes, hashes, dimensions, full Pillow decode and manifest completeness verified')
        for name in sorted(n for n in names if n.endswith('.log')):
            text = content(name)
            bad = []
            for line in text.splitlines():
                summary = re.fullmatch(r'SUMMARY: (\d+) PASS / (\d+) WARN / (\d+) FAIL', line)
                if name == 'project-validation.log' and summary:
                    if int(summary.group(3)) != 0:
                        bad.append(line)
                elif BAD.search(line):
                    bad.append(line)
            if bad:
                errors.append({'log': name, 'errors': bad})
            log_results[name] = {'bytes': len(z.read(name)), 'sha256': hashlib.sha256(z.read(name)).hexdigest(), 'errors': bad, 'markers': [line for line in text.splitlines() if 'PASS' in line or '[KartWinterVisibility]' in line]}
        for name, marker in REQUIRED[args.area].items():
            assert name in names, 'Missing required original gate: ' + name
            text = content(name)
            if marker not in text:
                errors.append({'log': name, 'missing_marker': marker})
            if name.startswith('render') or (name == 'regression.log' and args.area != 'home'):
                if 'OpenGL API' not in text:
                    errors.append({'log': name, 'error': 'Missing actual renderer identity'})
            if name == 'winter-visibility.log' and '[KartWorldExpansionCapture] PASS track=winter_sprint views=0' not in text:
                errors.append({'log': name, 'error': 'Missing real capture/audio teardown completion'})
        if args.area != 'feedback':
            assert content('baseline/source-sha.txt').strip() == BASELINE
            assert content('baseline/source-tree.txt').strip() == BASELINE_TREE
            required_baseline = {'baseline/render.log': '[KartHomeExperienceCapture] PASS'} if args.area == 'home' else {'baseline/render-winter_sprint.log': '[KartWorldExpansionCapture] PASS', 'baseline/render-crystal_canyon.log': '[KartWorldExpansionCapture] PASS'}
            for name, marker in required_baseline.items():
                if name not in names or marker not in content(name):
                    errors.append({'log': name, 'missing_baseline_marker': marker})
            assert 'baseline/import.log' in names
            checks.append('Exact prior baseline identity and independent import/render logs included')
        for name in sorted(n for n in names if n.endswith('.json') and (n.startswith('images/') or n.startswith('baseline/images/'))):
            reports[name] = json.loads(content(name))
        result = {
            'area': args.area, 'repository': 'Ullmann27/lumo-godot', 'run_id': RUN,
            'head_sha': HEAD, 'source_tree': TREE, 'artifact_id': artifact['id'],
            'archive': str(args.archive.resolve()), 'archive_sha256': digest,
            'archive_bytes': args.archive.stat().st_size, 'archive_entries': len(z.infolist()),
            'original_metadata_file': str(args.metadata.resolve()),
            'checks': checks, 'errors': errors, 'all_checked_gates_clean': not errors,
            'current_png_count': sum(i['current'] for i in images),
            'baseline_png_count': sum(not i['current'] for i in images),
            'images': images, 'logs': log_results, 'reports': reports,
            'png_decoder': 'Pillow ' + PIL.__version__ + ': Image.verify and full Image.load for every current and baseline PNG',
            'scope': 'Original-byte and log verification only. No visual approval, receipt, physical-device performance or Android acceptance.',
        }
        (root / (args.area + '-verified.json')).write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
        print(json.dumps({k: result[k] for k in ['area','artifact_id','archive_sha256','archive_bytes','archive_entries','current_png_count','baseline_png_count','all_checked_gates_clean','errors']}, ensure_ascii=False))
        return 0 if not errors else 1


if __name__ == '__main__':
    raise SystemExit(main())
