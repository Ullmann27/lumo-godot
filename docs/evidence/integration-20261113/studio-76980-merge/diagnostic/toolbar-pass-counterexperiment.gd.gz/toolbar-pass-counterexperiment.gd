extends "res://scripts/tests/build_dialog_density_regression.gd"

func _goal_access(profile: Array) -> void:
	var toolbar: ScrollContainer = game.tool_actions.get_parent()
	print("[ToolbarCounterexperiment] surface=", root.size, " previous_filter=", toolbar.mouse_filter)
	toolbar.mouse_filter = Control.MOUSE_FILTER_PASS
	await super._goal_access(profile)

func _world_camera_input() -> void:
	var previous_orbit: float = game.orbit
	await super._world_camera_input()
	print("[ToolbarCounterexperiment] completed surface=", root.size, " prior_orbit=", previous_orbit,
		" current_orbit=", game.orbit, " remaining_touches=", game.touches,
		" pointer=", game.pointer_id, " failures=", failures)
