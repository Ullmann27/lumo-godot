extends "res://scripts/tests/build_dialog_density_regression.gd"

var watching := false

func _world_camera_input() -> void:
	var upper := _pixels(game.upper_hud)
	var lower := _pixels(game.lower_hud)
	var strip_y := (upper.end.y + lower.position.y) * 0.5
	var start := Vector2(root.size.x * 0.42, strip_y)
	var end := start + Vector2(36.0 * density, 0.0)
	print("[GestureDiagnostic] setup surface=", root.size, " visible=", root.get_visible_rect(),
		" screen=", root.get_screen_transform(), " upper=", upper, " lower=", lower,
		" start=", start, " end=", end, " choice=", game.choice_window,
		" move=", game.move_mode, " object_drag=", game.object_drag, " touches=", game.touches,
		" pointer=", game.pointer_id, " orbit=", game.orbit)
	watching = true
	await super._world_camera_input()
	watching = false

func _touch(point: Vector2, pressed: bool) -> void:
	await super._touch(point, pressed)
	if watching:
		print("[GestureDiagnostic] touch pressed=", pressed, " point=", point,
			" touches=", game.touches, " pointer=", game.pointer_id,
			" object_drag=", game.object_drag, " touch_gesture=", game.touch_gesture,
			" orbit=", game.orbit, " hovered=", root.gui_get_hovered_control())

func _drag_screen(start: Vector2, end: Vector2) -> void:
	await _touch(start, true)
	var previous := start
	for step in range(1, 9):
		var point := start.lerp(end, float(step) / 8.0)
		var drag := InputEventScreenDrag.new()
		drag.index = 4
		drag.position = point
		drag.relative = point - previous
		drag.screen_relative = drag.relative
		drag.velocity = drag.relative * 60.0
		drag.screen_velocity = drag.velocity
		Input.parse_input_event(drag)
		Input.flush_buffered_events()
		previous = point
		await process_frame
		if watching:
			print("[GestureDiagnostic] drag step=", step, " point=", point,
				" touches=", game.touches, " pointer=", game.pointer_id, " dragged=", game.dragged,
				" object_drag=", game.object_drag, " orbit=", game.orbit,
				" hovered=", root.gui_get_hovered_control())
	await _touch(end, false)
	await _settle()
