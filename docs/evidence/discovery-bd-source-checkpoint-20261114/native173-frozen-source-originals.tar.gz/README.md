# Native PR173 Discovery follow-up on bd071225

This is a source-only proposed follow-up, based on Native `bd0712259bb64908a5649ee1999638826c9eb597` / tree `2eb628d3e3a327ee8985385130c96168db7aa852`. It does not alter the accepted bd branch, the frozen Host-Dream integration, an existing workflow or a pin. No tests, engine, renderer or device commands were run.

## Exact source selection

The original comparison is `454e81229b0193cba75844e9985a53deb2ce5c91...71a4c1e2304b52005950b12490d070c286c45438`; the final Producer tree is `8633c0ac611f2ba9f261cc247a60997634d43dd9`. Its 50 paths contain 22 active source/gate paths. Three are already byte-identical to bd and are excluded. Four Producer workflows and historical evidence are not installed. The resulting 19 selected files comprise six Hub files, four Village files, six Wonder files and three additional Producer gate sources.

All 19 published original source files are under `originals/source/`. Fourteen additions were reconstructed from complete immutable comparison hunks and independently matched to their exact published Git object IDs. The five existing-file changes were applied to fixed bd bytes at unique exact contexts; every resulting file matched the published end blob. Full source bytes, SHA256, Git object hashes and modes are retained. No binary asset is replaced.

## One concrete integration correction

The unchanged bd atelier already creates its own `LumoDreamAmbience`. The published Wonder garden created a second instance under a different parent. The existing idempotent attach function only deduplicates the same owner's immediate child.

The proposed product change passes the existing atelier parent to that function. The existing production-scene regression now recursively inspects the actual atelier tree and demands exactly one ambience, owned by the atelier and referenced by the Wonder garden. Its existing visual-only checks are also applied to that shared effect, preserving the prior object coverage. The seven flower mesh batches remain children of the Wonder garden. Only these two source files differ from the published Producer originals; `owner-integration.patch` isolates the correction. The expected100/108 markers remain in the source, but have not been executed or accepted on this proposal.

## Existing contracts preserved

The proposed patch does not modify the existing52-mode runner,17-image/movie/sidecar verifier, C4 Return21, Wisp14, Dream5/7/2 runner/reader, current Safe-Area sources, original Lumo assets, learning base implementation, Village economy or blocked-save behavior. The exact protected bd object IDs are recorded separately. The Producer Wisp18 variant, older Studio raster test and separate Live wrapper are not imported.

The new Hub keeps child/profile/save options, the existing router and the original facial rig. Village direct entry requires both opt-in fields, and its return uses the existing Save and Android acknowledgment path. Native Hub entry retains the Build return. The separate Host Village launch is not present in the current32e7 source according to the existing Host review; this pack makes no Android-launch claim.

## Acceptance still to connect

The three published Discovery gate sources are preserved as additional source candidates. They are not an activated Root acceptance pipeline. Their pure PNG reader verifies38 images and two reports, but it does not independently recheck ten original logs or pre/post source/index inventories. Its CLI labels `probes=10` after image verification; that field alone cannot establish ten fresh runs. The binding work and exact intended invocation are described in `gate-contract.json`.

Four of the ten Producer modes already exist in the untouched52 runner; six are additional. Any future reuse must map fresh same-head original bytes explicitly. Producer deadlines total2820 seconds; no inference about the existing90-minute Host job or physical-device speed is made.

## Original evidence boundaries

Five current71a PR workflows were successful in the saved original API response. None is a fresh full Discovery10/38 collection. The final Producer document explicitly states that its last checker replay used two fresh Hub pictures and36 earlier unchanged Learning/Wonder images. Those are Producer observations, not our own image review or a new combined-source acceptance. The Producer portrait Hub observation describes six visible cards plus two scroll entries. No images, movies or large archives are copied here.

Raw API responses are losslessly gzip-preserved where large, with raw and stored hashes. The original published comparison and PR response are also already retained as unreferenced evidence blobs in the Host repository; their identities are preserved in the metadata. The pack can be reviewed and checkpointed before targeted tests. All source strings and metadata are additionally kept in the active function store to survive another executor interruption.
