# Separate Discovery acceptance — source freeze only

This pack adds four files to **afc0df9a2b1794f39051add9dfce0cf947bb177b**, tree **3e621dc8230e155e1089deb1a40c22f177e546b3**, in Ullmann27/lumo-godot. Its parent is the independently accepted Dream source bd071225. The active source checkpoint and every existing file remain unchanged by this pack.

## Exact scope

The new workflow accepts only a push to **integration/lumo-discovery-bd-20261114**, in the original repository, and checks out the exact push SHA. This is a distinct branch from the pre-existing external `integration/lumo-discovery-connections-20261114`. The workflow has contents: read, a separate concurrency group with cancellation disabled, and a 120-minute job limit.

The four added files are listed with full SHA256/Git-blob identities and modes in `source-freeze.json`. No version, Native pin, active branch, commit, index, existing workflow, production file or previous evidence file is changed here. `integration.patch` contains exactly these four additions. The unchanged Producer reader/runner and the unchanged Dream helpers/tests/workflow are retained byte for byte under `originals/source/`; the authentic base commit and complete recursive tree API responses are retained under `originals/`.

## Collector and replay

```sh
python3 tools/collect_discovery_connections.py \
  --project "$GITHUB_WORKSPACE" \
  --output "$LUMO_DISCOVERY_EVIDENCE_DIR/discovery" \
  --expected-native-sha "$GITHUB_SHA" \
  --expected-native-tree "$LUMO_EXPECTED_NATIVE_TREE" \
  --godot "$GODOT_BIN"

python3 tools/verify_discovery_connections.py \
  "$LUMO_DISCOVERY_EVIDENCE_DIR/discovery" \
  --expected-native-sha "$GITHUB_SHA" \
  --expected-native-tree "$LUMO_EXPECTED_NATIVE_TREE"
```

The output's parent must already exist; the output itself must not exist or traverse a symlink and must be outside the Native source checkout. The full CI checkout must contain every tracked file. This does not reclassify Root's separately documented sparse local afc tests as full-checkout collection.

The collector copies and verifies the published reader **SHA256 55591b4478d2074135ea4950fb00200d68a3f9bede286b39642d7fc17aa586da / Git blob 219e691fc8aa119cc80221b3db6c77e63caf8bfe** before import. The Dream snapshot/PNG helper and existing engine-probe runner receive the same exact SHA256/Git-blob check. Their copies must also match the actual Native source tree. The two new collector/replay source copies are bound to that same tree.

The unchanged Dream snapshot function binds all tracked bytes/modes and the actual Git index before and after collection. The added verifier also reconstructs the complete recursive Git tree and validates the raw Git commit object against the externally supplied SHA/tree. Therefore omitting a tracked path from both inventories does not pass. Original raw index bytes and tree listings are retained; generated UID/import files have their own before/after inventory. There is no cleanup or source mutation.

Every call has original argv, environment, order, per-probe deadline, monotonic start/end and return code. The existing `tools/run_godot_probe.py` retains each original deadline and its existing five-second TERM/KILL grace. The verifier additionally rejects a call beyond its original deadline plus ten seconds of wrapper/grace overhead. It does not extend or retry an engine call. A partial/interrupted invocation list never passes.

Each of ten exact logs must contain exactly one expected engine banner and exactly one complete original success line. A second engine, another probe's marker, an error, timeout, crash, resource leak, failed return code or changed runner transcript is rejected. Captures must consist of exactly 38 PNGs and the two original reports, without missing/extra files or symlinks. Every PNG is fully verified and decoded through the unchanged Dream PNG helper, then the hash-bound Producer reader independently rechecks its original geometry, original Lumo identity, state, activity progression and changed completion pixels.

The final manifest is `discovery/discovery-acceptance.json`. The API `verify(root, expected_native_sha=..., expected_native_tree=..., write=False)` performs no writes. It recomputes from original files, checks their hashes again after verification and compares any existing manifest. The replay CLI additionally requires the original manifest to exist. The collector is the only writer of that manifest.

## Ten original mode contracts

The precise ordered argv/marker/log mapping is in `gate-contract.json`.

| Mode | Deadline |
| --- | ---: |
| LearningWorld headless | 420 s |
| LearningSharing headless | 420 s |
| LearningStudio headless | 420 s |
| Hub headless | 150 s |
| VillageHost headless | 150 s |
| Wonder headless | 150 s |
| Wonder rendered | 420 s |
| Hub capture rendered | 180 s |
| Learning capture rendered | 900 s |
| Wonder capture rendered | 420 s |

Total: **3,630 seconds**. The first three retain our existing 420-second budgets; the Producer's original 150-second values are preserved in its unchanged reference runner but are not used for these existing integration modes. Learning capture remains 900 seconds. The six added-mode budgets match the published Producer contract.

The 38 images are split into Hub 2, Learning 25 and Wonder 11. The two original reports are `captures/hub/hub-original-identity.json` and `captures/wonder/captures.json`. No old capture or Producer replay is substituted for a new current-source engine result.

## Separate workflow obligations

The workflow preserves the existing twelve Dream tests, Return21/Wisp14/Treasure92/Learning5347 headless gates, and all five Dream modes/seven images/two reports. It adds 24 focused Discovery-original counterexamples and the unchanged eleven Producer reader methods, with exact unittest method-count/OK checks so skipped or missing methods cannot appear as success.

It retains the proven Godot 4.6.3 zip SHA256 and exact engine version, Xvfb, and Pillow 12.3.0. The baseline workflow pins the Pillow version, not a wheel hash; this pack does not claim a wheel signature that the original did not provide. Engine, venv, temporary state and evidence paths are outside the checkout. The absolute venv PATH remains available to the unchanged Dream runner. All original logs, captures, reports, helper copies and source/index inventories are uploaded with `always()`, including failures, with 30-day Actions retention.

The original 52-mode / 17-image acceptance remains mandatory for a later Host integration and is neither executed nor renumbered by this separate workflow. Host's existing 90-minute budget is unchanged.

## Review and execution status

Only authoring, static Python source parsing and identity/provenance checks have occurred in this pack. **No new unit test, Actionlint, engine import, engine probe, renderer, device test or CI run has been executed.** The 24 test methods construct explicitly synthetic inputs and never constitute native runtime evidence. The source freeze must be published and independently reviewed before Root authorizes actual tests.

Pipeline's independent review is requested against the exact four frozen sources; any later review will be a separate original document. Root's real afc headless/reader results are separately retained under `/tmp/native-afc0df9-targeted-validation-20261114` and have not been relabeled as this new strict 10/38/2 result.

## Evidence limits

The intended result is source/log/raster acceptance for this separate Discovery collection. It does not establish full Native52/17 acceptance, a Host APK result, physical Android behavior, natural touchscreen gestures, audio playback on a device, FPS or a complete visual review. The final manifest states these boundaries explicitly.
