from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

os.environ.update(PYTHONDONTWRITEBYTECODE='1', GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0')
sys.dont_write_bytecode = True
ROOT = Path('/tmp/native-dd3ec7d-targeted-validation-20261114')
ROOT.mkdir(exist_ok=False)
(ROOT / 'runner.py').write_bytes(Path(__file__).read_bytes())
config = json.loads(Path('/tmp/lumo-root-recovery-1105/native173-strict-local-advance.json').read_text())
repo = Path(config['repo'])


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


objects = load('original_git_objects', '/workspace/scratch/b3485b7bb989/host-native-connect-four-integration-20261114/recovery-publications-20261114/recover_sparse_objects.py')
reader = repo / 'tools/verify_dream_rasters.py'
assert hashlib.sha256(reader.read_bytes()).hexdigest() == 'f7296a802d15c382dbcc77640373a0f53e30306fcaab3de869549ff1656de89d'
dream = load('original_dream_snapshot', reader)
advance = ROOT / 'advance'
advance.mkdir()
old = dream.snapshot_source(repo, advance, 'before')
assert old['head'] == config['expected_before']
for item in config['files']:
    objects.write_object(repo, 'blob', Path(item['file']).read_bytes(), item['entry']['sha'])
objects.import_tree(repo, {entry['path']: entry for entry in config['leaves']}, config['tree'])
objects.import_commit(repo, config['commit'])
objects.git(repo, 'switch', '-c', 'validation/discovery-dd3ec7d-20261114', config['commit']['sha'])
new = dream.snapshot_source(repo, advance, 'after')
assert (new['head'], new['tree']) == (config['commit']['sha'], config['tree'])
new_by_path = {entry['path']: entry for entry in new['tracked']}
assert all(new_by_path[entry['path']] == entry for entry in old['tracked'])
assert old['untracked_import_inventory'] == new['untracked_import_inventory']

source = ROOT / 'source'
source.mkdir()
before = dream.snapshot_source(repo, source, 'before')
results = []
commands = [
    ('counterexamples', [sys.executable, '-m', 'unittest', 'tools.tests.test_discovery_connections', '-v'], 240),
    ('actionlint', ['/workspace/scratch/e0abce7d2838/toolchain/actionlint/actionlint', '.github/workflows/lumo-discovery-connections.yml'], 60),
]
for name, command, timeout in commands:
    start = datetime.now(timezone.utc).isoformat()
    tick = time.monotonic()
    argv = ['timeout', '--signal=TERM', '--kill-after=5s', f'{timeout}s', *command]
    run = subprocess.run(argv, cwd=repo, capture_output=True)
    (ROOT / (name + '.stdout.log')).write_bytes(run.stdout)
    (ROOT / (name + '.stderr.log')).write_bytes(run.stderr)
    success = run.returncode == 0
    if name == 'counterexamples':
        text = (run.stdout + b'\n' + run.stderr).decode('utf-8')
        success = success and re.search(r'Ran 24 tests in [0-9.]+s\s+OK\s*$', text) is not None
        success = success and not re.search(r'\b(?:skipped|FAILED|ERROR)\b', text)
    record = {'name': name, 'argv': argv, 'started_at_utc': start,
              'finished_at_utc': datetime.now(timezone.utc).isoformat(),
              'elapsed_seconds': time.monotonic() - tick, 'returncode': run.returncode,
              'pass': bool(success)}
    results.append(record)
    (ROOT / (name + '.result.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
after = dream.snapshot_source(repo, source, 'after')
unchanged = all(before[key] == after[key] for key in ('head', 'tree', 'index_sha256', 'tracked', 'untracked_import_inventory'))
summary = {'schema': 1, 'head': config['commit']['sha'], 'tree': config['tree'],
           'status': 'PASS' if unchanged and all(result['pass'] for result in results) else 'FAIL',
           'results': results, 'tracked_files': len(before['tracked']),
           'materialized_files': sum(entry['materialized'] for entry in before['tracked']),
           'explicit_sparse_files': sum(entry['skip_worktree'] for entry in before['tracked']),
           'source_index_and_generated_metadata_unchanged': unchanged,
           'new_counterexample_cases': 24, 'skips': 0,
           'actual_engine_runs': 0, 'actual_renderer_runs': 0,
           'scope': 'Exactly the new24 reader/collector counterexamples and one Actionlint on dd3ec7d; no product/renderer acceptance transfer.'}
(ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
raise SystemExit(0 if summary['status'] == 'PASS' else 1)
