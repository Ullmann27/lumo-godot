from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

PROJECT = Path('/tmp/lumo-root-recovery-1105/native-discovery')
OUTPUT = Path('/tmp/native-afc0df9-targeted-validation-20261114')
HEAD = 'afc0df9a2b1794f39051add9dfce0cf947bb177b'
TREE = '3e621dc8230e155e1089deb1a40c22f177e546b3'
ENGINE = Path('/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64')
VERSION = '4.6.3.stable.official.7d41c59c4'
ERRORS = re.compile(r'SCRIPT ERROR|Parse Error|ERROR:|Assertion failed|ObjectDB instances leaked|resources still in use at exit')
os.environ.update(PYTHONDONTWRITEBYTECODE='1', GIT_NO_LAZY_FETCH='1',
                  GIT_TERMINAL_PROMPT='0', GIT_OPTIONAL_LOCKS='0')
sys.dont_write_bytecode = True
OUTPUT.mkdir(exist_ok=False)
(OUTPUT / 'runner.py').write_bytes(Path(__file__).read_bytes())
reader = PROJECT / 'tools/verify_dream_rasters.py'
assert hashlib.sha256(reader.read_bytes()).hexdigest() == 'f7296a802d15c382dbcc77640373a0f53e30306fcaab3de869549ff1656de89d'
spec = importlib.util.spec_from_file_location('bound_dream_source_snapshot', reader)
snapshot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(snapshot)
before = snapshot.snapshot_source(PROJECT, OUTPUT, 'before')
assert (before['head'], before['tree']) == (HEAD, TREE)
results = []


def run(name, argv, seconds, marker=None, engine=False):
    state = OUTPUT / 'state' / name
    for directory in ('data', 'config', 'cache'):
        (state / directory).mkdir(parents=True, exist_ok=False)
    env = {**os.environ, 'GODOT_SILENCE_ROOT_WARNING': '1',
           'PYTHONPATH': str(PROJECT / 'tools') + os.pathsep + str(PROJECT / 'tools/tests'),
           'XDG_DATA_HOME': str(state / 'data'), 'XDG_CONFIG_HOME': str(state / 'config'),
           'XDG_CACHE_HOME': str(state / 'cache')}
    started = datetime.now(timezone.utc).isoformat()
    tick = time.monotonic()
    timed_out = False
    command = ['timeout', '--signal=TERM', '--kill-after=5s', f'{seconds}s', *map(str, argv)]
    completed = subprocess.run(command, cwd=PROJECT, env=env, capture_output=True)
    (OUTPUT / (name + '.stdout.log')).write_bytes(completed.stdout)
    (OUTPUT / (name + '.stderr.log')).write_bytes(completed.stderr)
    text = (completed.stdout + b'\n' + completed.stderr).decode('utf-8', errors='strict')
    timed_out = completed.returncode in (124, 137)
    errors = ERRORS.findall(text) if engine else []
    marker_count = None if marker is None else text.splitlines().count(marker)
    banner_count = sum(line.startswith('Godot Engine v' + VERSION) for line in text.splitlines()) if engine else None
    success = completed.returncode == 0 and not timed_out and not errors
    if marker is not None:
        success = success and marker_count == 1
    if engine:
        success = success and banner_count == 1
    if name == 'discovery-reader-tests':
        success = success and re.search(r'Ran 11 tests in [0-9.]+s\s+OK\s*$', text) is not None
        success = success and not re.search(r'\b(?:skipped|FAILED|ERROR)\b', text)
    record = {'name': name, 'argv': command, 'started_at_utc': started,
              'finished_at_utc': datetime.now(timezone.utc).isoformat(),
              'elapsed_seconds': time.monotonic() - tick, 'returncode': completed.returncode,
              'timed_out': timed_out, 'marker': marker, 'marker_count': marker_count,
              'engine_banner_count': banner_count, 'error_markers': errors, 'pass': bool(success)}
    results.append(record)
    (OUTPUT / (name + '.result.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if not success:
        raise RuntimeError('Targeted gate failed: ' + name)


failure = None
try:
    version = subprocess.run([str(ENGINE), '--version'], capture_output=True, check=True, timeout=10)
    (OUTPUT / 'engine-version.stdout.log').write_bytes(version.stdout)
    (OUTPUT / 'engine-version.stderr.log').write_bytes(version.stderr)
    assert version.stdout.decode().strip() == VERSION
    (OUTPUT / 'engine.json').write_text(json.dumps({'path': str(ENGINE), 'version': VERSION,
        'sha256': hashlib.sha256(ENGINE.read_bytes()).hexdigest()}, indent=2) + '\n')
    run('discovery-reader-tests', [sys.executable, '-m', 'unittest', 'test_discovery_rasters', '-v'], 180)
    run('import', [ENGINE, '--headless', '--audio-driver', 'Dummy', '--path', PROJECT,
                   '--editor', '--import', '--quit'], 420, engine=True)
    gates = [
        ('game_hub_magic_regression', 150, '[LumoHub] PASS 8 visible native game entrances, active village route, preserved child settings and 3D reduced-motion portal'),
        ('village_host_launch_regression', 150, '[VillageHost] PASS Flutter village request, native boot scene and child context'),
        ('learning_wonder_details_regression', 150, '[LearningWonder] checks=100 failures=0 renderer=headless invalid_scene_checked=false'),
        ('lumo_dream_ambience_regression', 120, '[DreamAmbience] 170 checks, 0 failures'),
        ('dream_garden_props_regression', 120, '[DreamGarden] checks=544 failures=0'),
    ]
    for name, seconds, marker in gates:
        run(name, [ENGINE, '--headless', '--audio-driver', 'Dummy', '--path', PROJECT,
                   '--script', f'res://scripts/tests/{name}.gd'], seconds, marker, engine=True)
except Exception as error:
    failure = {'type': type(error).__name__, 'message': str(error)}
finally:
    after = snapshot.snapshot_source(PROJECT, OUTPUT, 'after')
    unchanged = all(before[key] == after[key] for key in ('head', 'tree', 'index_sha256', 'tracked'))
    summary = {'schema': 1, 'head': HEAD, 'tree': TREE, 'results': results,
               'failure': failure, 'source_and_index_unchanged': unchanged,
               'status': 'PASS' if failure is None and unchanged and len(results) == 7 else 'FAIL',
               'python_cases': 11 if results and results[0]['pass'] else None,
               'rendered_discovery_acceptance': 'NOT_RUN', 'apk_or_device_acceptance': 'NOT_RUN',
               'scope': '11 producer reader cases, one real import and five exact headless probes on afc0df9 only.'}
    (OUTPUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)
    if summary['status'] != 'PASS':
        sys.exit(1)
