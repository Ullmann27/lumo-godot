# Native Dream: enger lokaler Nachweis auf c2e025f

Dieser Pack bindet ausschließlich den veröffentlichten Native-Commit `c2e025f9bb34334323d989b19085f6fe0e6c5694`, Tree `24c4bfe70a0b3c575b4c6209973ff244237f7b19`. Er enthält genau den freigegebenen ersten Test-/Engine-Lauf: 12 Python-Vertragsmethoden ohne Fehler oder Skips, einen sauberen Godot-4.6.3-Import, DreamAmbience 170/0 und DreamGarden 544/0 über den unveränderten strengen Originalrunner. Beide Headless-Fristen blieben 120 Sekunden; beide vollständigen Originalmarker stehen jeweils genau einmal in den sauberen Logs.

## Quellen und Sparse-Auswahl

HEAD, Tree, Indexbytes, sämtliche 1.468 materialisierten getrackten Quelldateien einschließlich Modi und alle 2.139 fehlenden skip-worktree-Einträge sind vorher/nachher identisch. Die ausgelassenen Pfade sind docs/2.083, evidence/8 und tools/48. Der Quellenabschluss weist sie vollständig aus. Die tools-Untergruppen sind ai3d/2, android_patches/20, argon_review/1, art/16, harbor/1, lumo_animation/6 und qa/2. Keine direkte Import- oder Fixtureabhängigkeit der 12 Methoden und zwei Dream-Probes liegt darin; 36 literal gebundene Godot-Ressourcenkanten sind vorhanden. Dynamische Enginebelege stammen ausschließlich aus den tatsächlichen Originalausführungen.

Ein früherer lokaler Collector-Vorabcheck nahm fälschlich an, alle 2.139 ausgelassenen Pfade lägen unter docs/. Er stoppte vor Tests und Engine (`stages=[]`). Seine unveränderten Bytes liegen im Archiv separat unter `preflight/`; `actual/` enthält den ersten tatsächlichen Lauf. Die Korrektur betrifft nur diese unbegründete Pfadpräfixannahme. Quellen-/Index-/Modeabweichungen bleiben verboten.

## Generierte Dateien

337 neue UID-Dateien und 463 neue Import-Metadaten wurden bytegleich in `generated-import-originals.tar.gz` archiviert; alle 800 Mitglieder wurden vollständig zurückgelesen und gegen ihre Originalhashes geprüft. Sämtliche Dateien bleiben im Checkout, es gab keine Bereinigung. Der ignorierte Importcache (1.033 Dateien, 76.986.000 Bytes) ist vollständig mit SHA256 inventarisiert und bleibt lokal vorhanden; sein reproduzierbarer Payload wird im kompakten Pack nicht dupliziert.

## Originalretention und Grenzen

Das Transportarchiv enthält die vollständigen Rohlogs, Befehle/Umgebungswerte, Quellen-/Indexinventare, expliziten Sparse-Pfade, Quellenvergleich, erzeugten UID-/Importoriginale sowie den ursprünglichen Fehlvorabcheck. Das Manifest benennt jeden ursprünglichen Dateipfad und seine Bytes/SHA256. `SHA256SUMS` gilt für die logischen Pfade nach Archiventpackung. Der vollständige Archivroundtrip wurde geprüft. Keine Quelldatei, kein Git-Index/Ref und kein Workflow wurde verändert.

Es gab keinen lokalen Renderer- oder Gerätelauf, keine neuen Spiel-PNGs und keine Wiederholung der vier Bestandstests. Die sieben echten Dream-PNGs und die drei Renderer-Modi sind weiterhin offen. Ebenso wird keine vollständige52/17-, Android- oder FPS-Abnahme behauptet. Die synthetischen Rastertests liefen mit lokalem Pillow13.0.0; der veröffentlichte Workflow deklariert12.3.0. Dieser Umgebungsunterschied bleibt ausdrücklich sichtbar.
